# Agent驱动的自动笔记提取系统 - 实现计划

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** 构建一个基于Agent的自动笔记提取系统，支持从PDF/网页/文本生成结构化笔记

**Architecture:** 自研ReAct Agent引擎，FastAPI后端 + React前端，通过LLM抽象层调用国内API

**Tech Stack:** Python 3.10+, FastAPI, SQLAlchemy, React, TypeScript, Ant Design

---

## 文件结构

```
agent/
├── backend/
│   ├── app/
│   │   ├── __init__.py
│   │   ├── main.py
│   │   ├── config.py
│   │   ├── database.py
│   │   ├── api/
│   │   │   ├── __init__.py
│   │   │   ├── notes.py
│   │   │   └── tasks.py
│   │   ├── agent/
│   │   │   ├── __init__.py
│   │   │   ├── engine.py
│   │   │   ├── planner.py
│   │   │   └── reflector.py
│   │   ├── tools/
│   │   │   ├── __init__.py
│   │   │   ├── registry.py
│   │   │   ├── pdf_parser.py
│   │   │   ├── web_scraper.py
│   │   │   └── text_processor.py
│   │   ├── llm/
│   │   │   ├── __init__.py
│   │   │   ├── base.py
│   │   │   └── qwen.py
│   │   ├── models/
│   │   │   ├── __init__.py
│   │   │   ├── note.py
│   │   │   └── task.py
│   │   └── services/
│   │       ├── __init__.py
│   │       ├── note_service.py
│   │       └── task_service.py
│   ├── tests/
│   │   ├── __init__.py
│   │   ├── test_llm.py
│   │   ├── test_tools.py
│   │   ├── test_agent.py
│   │   ├── test_notes_api.py
│   │   └── conftest.py
│   └── requirements.txt
├── frontend/
│   ├── package.json
│   ├── tsconfig.json
│   ├── src/
│   │   ├── App.tsx
│   │   ├── index.tsx
│   │   ├── api/
│   │   │   └── client.ts
│   │   ├── pages/
│   │   │   ├── HomePage.tsx
│   │   │   ├── NoteListPage.tsx
│   │   │   └── NoteDetailPage.tsx
│   │   └── components/
│   │       ├── FileUpload.tsx
│   │       ├── NoteEditor.tsx
│   │       └── NoteViewer.tsx
│   └── public/
│       └── index.html
└── docs/
    └── superpowers/
        └── specs/
```

---

## Task 1: 后端项目初始化与依赖配置

**Files:**
- Create: `backend/requirements.txt`
- Create: `backend/app/__init__.py`
- Create: `backend/app/config.py`
- Create: `backend/app/main.py`
- Create: `backend/tests/__init__.py`
- Create: `backend/tests/conftest.py`

- [ ] **Step 1: 创建requirements.txt**

```txt
fastapi==0.109.0
uvicorn==0.27.0
sqlalchemy==2.0.25
aiosqlite==0.19.0
pdfplumber==0.10.3
requests==2.31.0
beautifulsoup4==4.12.3
dashscope==1.14.1
python-multipart==0.0.6
pydantic==2.5.3
pytest==7.4.4
pytest-asyncio==0.23.3
httpx==0.26.0
```

- [ ] **Step 2: 创建配置文件backend/app/config.py**

```python
from pydantic_settings import BaseSettings
from functools import lru_cache


class Settings(BaseSettings):
    app_name: str = "Agent Note Extraction"
    database_url: str = "sqlite+aiosqlite:///./notes.db"
    qwen_api_key: str = ""
    qwen_model: str = "qwen-turbo"
    
    class Config:
        env_file = ".env"


@lru_cache()
def get_settings() -> Settings:
    return Settings()
```

- [ ] **Step 3: 创建FastAPI入口backend/app/main.py**

```python
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

app = FastAPI(title="Agent Note Extraction")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:3000"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.get("/")
async def root():
    return {"message": "Agent Note Extraction API"}
```

- [ ] **Step 4: 创建测试配置backend/tests/conftest.py**

```python
import pytest
from fastapi.testclient import TestClient
from app.main import app


@pytest.fixture
def client():
    return TestClient(app)
```

- [ ] **Step 5: 运行测试验证项目结构**

Run: `cd backend && python -m pytest tests/ -v`
Expected: 1 test passed (test root endpoint if added)

- [ ] **Step 6: 启动服务验证**

Run: `cd backend && uvicorn app.main:app --reload`
Expected: Server running on http://127.0.0.1:8000

- [ ] **Step 7: Commit**

```bash
git add backend/
git commit -m "feat: initialize backend project with FastAPI"
```

---

## Task 2: 数据库模型设计

**Files:**
- Create: `backend/app/database.py`
- Create: `backend/app/models/__init__.py`
- Create: `backend/app/models/note.py`
- Create: `backend/app/models/task.py`
- Modify: `backend/app/main.py`

- [ ] **Step 1: 创建数据库连接backend/app/database.py**

```python
from sqlalchemy.ext.asyncio import create_async_engine, AsyncSession, async_sessionmaker
from sqlalchemy.orm import DeclarativeBase
from app.config import get_settings

settings = get_settings()
engine = create_async_engine(settings.database_url, echo=True)
async_session = async_sessionmaker(engine, class_=AsyncSession, expire_on_commit=False)


class Base(DeclarativeBase):
    pass


async def get_db():
    async with async_session() as session:
        try:
            yield session
            await session.commit()
        except Exception:
            await session.rollback()
            raise


async def init_db():
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
```

- [ ] **Step 2: 创建Note模型backend/app/models/note.py**

```python
import uuid
from datetime import datetime
from sqlalchemy import Column, String, Text, DateTime, Enum
from app.database import Base
import enum


class SourceType(str, enum.Enum):
    PDF = "pdf"
    WEB = "web"
    TEXT = "text"


class NoteType(str, enum.Enum):
    OUTLINE = "outline"
    QA = "qa"
    FULL = "full"


class Note(Base):
    __tablename__ = "notes"

    id = Column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    title = Column(String, nullable=False)
    source_type = Column(Enum(SourceType), nullable=False)
    source_url = Column(String, nullable=True)
    content_raw = Column(Text, nullable=False)
    content_markdown = Column(Text, nullable=False)
    note_type = Column(Enum(NoteType), nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
```

- [ ] **Step 3: 创建Task模型backend/app/models/task.py**

```python
import uuid
from datetime import datetime
from sqlalchemy import Column, String, Text, DateTime, Enum, ForeignKey, JSON
from sqlalchemy.orm import relationship
from app.database import Base
import enum


class TaskStatus(str, enum.Enum):
    PENDING = "pending"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"


class Task(Base):
    __tablename__ = "tasks"

    id = Column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    note_id = Column(String, ForeignKey("notes.id"), nullable=True)
    status = Column(Enum(TaskStatus), default=TaskStatus.PENDING)
    steps = Column(JSON, default=list)
    result = Column(Text, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)

    note = relationship("Note", backref="tasks")
```

- [ ] **Step 4: 更新main.py初始化数据库**

修改 `backend/app/main.py`:

```python
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from contextlib import asynccontextmanager
from app.database import init_db


@asynccontextmanager
async def lifespan(app: FastAPI):
    await init_db()
    yield


app = FastAPI(title="Agent Note Extraction", lifespan=lifespan)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:3000"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.get("/")
async def root():
    return {"message": "Agent Note Extraction API"}
```

- [ ] **Step 5: 运行测试验证数据库初始化**

Run: `cd backend && python -c "from app.database import init_db; import asyncio; asyncio.run(init_db())"`
Expected: notes.db created without errors

- [ ] **Step 6: Commit**

```bash
git add backend/app/database.py backend/app/models/
git commit -m "feat: add database models for Note and Task"
```

---

## Task 3: LLM抽象层实现

**Files:**
- Create: `backend/app/llm/__init__.py`
- Create: `backend/app/llm/base.py`
- Create: `backend/app/llm/qwen.py`
- Create: `backend/tests/test_llm.py`

- [ ] **Step 1: 编写LLM测试backend/tests/test_llm.py**

```python
import pytest
from app.llm.base import LLMProvider
from app.llm.qwen import QwenProvider


def test_llm_provider_is_abstract():
    with pytest.raises(TypeError):
        LLMProvider()


def test_qwen_provider_implements_interface():
    provider = QwenProvider(api_key="test_key")
    assert isinstance(provider, LLMProvider)
    assert hasattr(provider, 'chat')
    assert hasattr(provider, 'stream_chat')
```

- [ ] **Step 2: 运行测试验证失败**

Run: `cd backend && python -m pytest tests/test_llm.py -v`
Expected: FAIL - module not found

- [ ] **Step 3: 创建LLM基类backend/app/llm/base.py**

```python
from abc import ABC, abstractmethod
from typing import List, Dict, Any, AsyncIterator


class LLMProvider(ABC):
    """LLM提供者的抽象基类"""

    @abstractmethod
    async def chat(
        self,
        messages: List[Dict[str, str]],
        tools: List[Dict[str, Any]] = None
    ) -> Dict[str, Any]:
        """发送聊天请求，返回响应"""
        pass

    @abstractmethod
    async def stream_chat(
        self,
        messages: List[Dict[str, str]],
        tools: List[Dict[str, Any]] = None
    ) -> AsyncIterator[str]:
        """流式聊天请求"""
        pass
```

- [ ] **Step 4: 创建QwenProvider实现backend/app/llm/qwen.py**

```python
from typing import List, Dict, Any, AsyncIterator
import dashscope
from dashscope import Generation
from app.llm.base import LLMProvider


class QwenProvider(LLMProvider):
    """通义千问LLM提供者"""

    def __init__(self, api_key: str, model: str = "qwen-turbo"):
        self.api_key = api_key
        self.model = model
        dashscope.api_key = api_key

    async def chat(
        self,
        messages: List[Dict[str, str]],
        tools: List[Dict[str, Any]] = None
    ) -> Dict[str, Any]:
        response = Generation.call(
            model=self.model,
            messages=messages,
            result_format="message"
        )
        return {
            "content": response.output.choices[0].message.content,
            "usage": response.usage
        }

    async def stream_chat(
        self,
        messages: List[Dict[str, str]],
        tools: List[Dict[str, Any]] = None
    ) -> AsyncIterator[str]:
        responses = Generation.call(
            model=self.model,
            messages=messages,
            result_format="message",
            stream=True
        )
        for response in responses:
            if response.output and response.output.choices:
                yield response.output.choices[0].message.content
```

- [ ] **Step 5: 创建__init__.py文件backend/app/llm/__init__.py**

```python
from app.llm.base import LLMProvider
from app.llm.qwen import QwenProvider

__all__ = ["LLMProvider", "QwenProvider"]
```

- [ ] **Step 6: 运行测试验证通过**

Run: `cd backend && python -m pytest tests/test_llm.py -v`
Expected: 2 tests passed

- [ ] **Step 7: Commit**

```bash
git add backend/app/llm/ backend/tests/test_llm.py
git commit -m "feat: implement LLM abstraction layer with QwenProvider"
```

---

## Task 4: 工具注册机制实现

**Files:**
- Create: `backend/app/tools/__init__.py`
- Create: `backend/app/tools/registry.py`
- Create: `backend/tests/test_tools.py`

- [ ] **Step 1: 编写工具注册表测试backend/tests/test_tools.py**

```python
import pytest
from app.tools.registry import ToolRegistry, tool


@tool(name="test_tool", description="A test tool")
def test_tool_func(input: str) -> str:
    return f"processed: {input}"


def test_tool_registration():
    registry = ToolRegistry()
    assert "test_tool" in registry.list_tools()


def test_tool_execution():
    registry = ToolRegistry()
    result = registry.execute("test_tool", input="hello")
    assert result == "processed: hello"


def test_tool_not_found():
    registry = ToolRegistry()
    with pytest.raises(KeyError):
        registry.execute("nonexistent_tool")
```

- [ ] **Step 2: 运行测试验证失败**

Run: `cd backend && python -m pytest tests/test_tools.py -v`
Expected: FAIL - module not found

- [ ] **Step 3: 创建工具注册表backend/app/tools/registry.py**

```python
from typing import Callable, Dict, Any, List
import functools


class ToolRegistry:
    """工具注册表"""
    _instance = None
    _tools: Dict[str, Callable] = {}

    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        return cls._instance

    @classmethod
    def register(cls, name: str, description: str):
        """工具装饰器"""
        def decorator(func):
            @functools.wraps(func)
            def wrapper(*args, **kwargs):
                return func(*args, **kwargs)
            wrapper._tool_name = name
            wrapper._tool_description = description
            cls._tools[name] = wrapper
            return wrapper
        return decorator

    @classmethod
    def get_tool(cls, name: str) -> Callable:
        """获取工具"""
        if name not in cls._tools:
            raise KeyError(f"Tool '{name}' not found")
        return cls._tools[name]

    @classmethod
    def execute(cls, name: str, **kwargs) -> Any:
        """执行工具"""
        tool = cls.get_tool(name)
        return tool(**kwargs)

    @classmethod
    def list_tools(cls) -> List[Dict[str, str]]:
        """列出所有工具"""
        return [
            {"name": name, "description": tool._tool_description}
            for name, tool in cls._tools.items()
        ]


def tool(name: str, description: str):
    """工具装饰器的快捷方式"""
    return ToolRegistry.register(name, description)
```

- [ ] **Step 4: 创建__init__.py文件backend/app/tools/__init__.py**

```python
from app.tools.registry import ToolRegistry, tool

__all__ = ["ToolRegistry", "tool"]
```

- [ ] **Step 5: 运行测试验证通过**

Run: `cd backend && python -m pytest tests/test_tools.py -v`
Expected: 3 tests passed

- [ ] **Step 6: Commit**

```bash
git add backend/app/tools/ backend/tests/test_tools.py
git commit -m "feat: implement tool registry mechanism"
```

---

## Task 5: PDF解析工具实现

**Files:**
- Create: `backend/app/tools/pdf_parser.py`

- [ ] **Step 1: 创建PDF解析工具backend/app/tools/pdf_parser.py**

```python
import pdfplumber
from app.tools.registry import tool


@tool(name="parse_pdf", description="解析PDF文件，提取文本内容")
def parse_pdf(file_path: str) -> str:
    """
    解析PDF文件并提取文本内容
    
    Args:
        file_path: PDF文件路径
        
    Returns:
        提取的文本内容
    """
    text_content = []
    
    with pdfplumber.open(file_path) as pdf:
        for page in pdf.pages:
            text = page.extract_text()
            if text:
                text_content.append(text)
    
    return "\n\n".join(text_content)


@tool(name="parse_pdf_pages", description="解析PDF文件的指定页码范围")
def parse_pdf_pages(file_path: str, start_page: int = 0, end_page: int = None) -> str:
    """
    解析PDF文件的指定页码范围
    
    Args:
        file_path: PDF文件路径
        start_page: 起始页码（从0开始）
        end_page: 结束页码（不包含），None表示到最后
        
    Returns:
        提取的文本内容
    """
    text_content = []
    
    with pdfplumber.open(file_path) as pdf:
        if end_page is None:
            end_page = len(pdf.pages)
        
        for i in range(start_page, min(end_page, len(pdf.pages))):
            text = pdf.pages[i].extract_text()
            if text:
                text_content.append(f"--- 第{i+1}页 ---\n{text}")
    
    return "\n\n".join(text_content)
```

- [ ] **Step 2: 测试PDF解析工具**

创建测试PDF文件，运行：
```bash
cd backend && python -c "
from app.tools.pdf_parser import parse_pdf
# 需要准备一个测试PDF
# result = parse_pdf('test.pdf')
# print(result[:500])
print('PDF parser tool created successfully')
"
```

- [ ] **Step 3: Commit**

```bash
git add backend/app/tools/pdf_parser.py
git commit -m "feat: implement PDF parser tool"
```

---

## Task 6: 网页抓取工具实现

**Files:**
- Create: `backend/app/tools/web_scraper.py`

- [ ] **Step 1: 创建网页抓取工具backend/app/tools/web_scraper.py**

```python
import requests
from bs4 import BeautifulSoup
from app.tools.registry import tool


@tool(name="scrape_web", description="抓取网页内容，过滤广告和导航")
def scrape_web(url: str) -> str:
    """
    抓取网页内容并提取主要文本
    
    Args:
        url: 网页URL
        
    Returns:
        提取的文本内容
    """
    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"
    }
    
    response = requests.get(url, headers=headers, timeout=30)
    response.raise_for_status()
    response.encoding = response.apparent_encoding
    
    soup = BeautifulSoup(response.text, "html.parser")
    
    # 移除不需要的标签
    for tag in soup(["script", "style", "nav", "footer", "header", "aside"]):
        tag.decompose()
    
    # 提取主要内容
    content = []
    
    # 优先提取article或main标签
    main_content = soup.find("article") or soup.find("main") or soup.find("body")
    
    if main_content:
        for element in main_content.find_all(["h1", "h2", "h3", "h4", "p", "li"]):
            text = element.get_text(strip=True)
            if text:
                if element.name.startswith("h"):
                    level = int(element.name[1])
                    content.append(f"\n{'#' * level} {text}\n")
                else:
                    content.append(text)
    
    return "\n\n".join(content)


@tool(name="scrape_web_raw", description="抓取网页原始HTML内容")
def scrape_web_raw(url: str) -> str:
    """
    抓取网页原始HTML
    
    Args:
        url: 网页URL
        
    Returns:
        原始HTML内容
    """
    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"
    }
    
    response = requests.get(url, headers=headers, timeout=30)
    response.raise_for_status()
    return response.text
```

- [ ] **Step 2: 测试网页抓取工具**

```bash
cd backend && python -c "
from app.tools.web_scraper import scrape_web
# result = scrape_web('https://example.com')
# print(result[:500])
print('Web scraper tool created successfully')
"
```

- [ ] **Step 3: Commit**

```bash
git add backend/app/tools/web_scraper.py
git commit -m "feat: implement web scraper tool"
```

---

## Task 7: 文本处理工具实现

**Files:**
- Create: `backend/app/tools/text_processor.py`

- [ ] **Step 1: 创建文本处理工具backend/app/tools/text_processor.py**

```python
from typing import List
from app.tools.registry import tool


@tool(name="process_text", description="处理纯文本输入，进行清洗和分段")
def process_text(text: str) -> str:
    """
    处理纯文本，清洗并保留结构
    
    Args:
        text: 输入文本
        
    Returns:
        处理后的文本
    """
    # 移除多余空白
    lines = text.split("\n")
    cleaned_lines = []
    
    for line in lines:
        stripped = line.strip()
        if stripped:
            cleaned_lines.append(stripped)
    
    return "\n".join(cleaned_lines)


@tool(name="split_text_chunks", description="将长文本按段落分块")
def split_text_chunks(text: str, max_chunk_size: int = 2000) -> List[str]:
    """
    将长文本分块，每块不超过max_chunk_size字符
    
    Args:
        text: 输入文本
        max_chunk_size: 每块最大字符数
        
    Returns:
        文本块列表
    """
    paragraphs = text.split("\n\n")
    chunks = []
    current_chunk = []
    current_size = 0
    
    for para in paragraphs:
        para_size = len(para)
        
        if current_size + para_size > max_chunk_size and current_chunk:
            chunks.append("\n\n".join(current_chunk))
            current_chunk = [para]
            current_size = para_size
        else:
            current_chunk.append(para)
            current_size += para_size
    
    if current_chunk:
        chunks.append("\n\n".join(current_chunk))
    
    return chunks


@tool(name="merge_chunks", description="合并多个文本块")
def merge_chunks(chunks: List[str], separator: str = "\n\n---\n\n") -> str:
    """
    合并多个文本块
    
    Args:
        chunks: 文本块列表
        separator: 分隔符
        
    Returns:
        合并后的文本
    """
    return separator.join(chunks)
```

- [ ] **Step 2: 测试文本处理工具**

```bash
cd backend && python -c "
from app.tools.text_processor import process_text, split_text_chunks

test_text = '''
  Hello World
  
  This is a test paragraph.
  
  Another paragraph here.
'''

result = process_text(test_text)
print('Processed:', repr(result))

chunks = split_text_chunks('a' * 5000, max_chunk_size=1000)
print('Chunks:', len(chunks))
"
```

- [ ] **Step 3: Commit**

```bash
git add backend/app/tools/text_processor.py
git commit -m "feat: implement text processor tool"
```

---

## Task 8: Agent引擎核心实现

**Files:**
- Create: `backend/app/agent/__init__.py`
- Create: `backend/app/agent/engine.py`
- Create: `backend/app/agent/planner.py`
- Create: `backend/app/agent/reflector.py`
- Create: `backend/tests/test_agent.py`

- [ ] **Step 1: 编写Agent引擎测试backend/tests/test_agent.py**

```python
import pytest
from unittest.mock import AsyncMock, MagicMock
from app.agent.engine import AgentEngine
from app.llm.base import LLMProvider


@pytest.fixture
def mock_llm():
    llm = AsyncMock(spec=LLMProvider)
    llm.chat.return_value = {
        "content": '{"action": "finish", "result": "Test note content"}'
    }
    return llm


def test_agent_engine_initialization(mock_llm):
    engine = AgentEngine(llm=mock_llm)
    assert engine.llm == mock_llm
    assert engine.max_steps == 10


@pytest.mark.asyncio
async def test_agent_engine_run(mock_llm):
    engine = AgentEngine(llm=mock_llm)
    result = await engine.run(
        content="Test content",
        note_type="outline"
    )
    assert result is not None
    assert "content" in result
```

- [ ] **Step 2: 运行测试验证失败**

Run: `cd backend && python -m pytest tests/test_agent.py -v`
Expected: FAIL - module not found

- [ ] **Step 3: 创建规划模块backend/app/agent/planner.py**

```python
from typing import Dict, Any, List
from app.llm.base import LLMProvider


class Planner:
    """Agent规划模块"""

    def __init__(self, llm: LLMProvider):
        self.llm = llm

    async def plan(self, content: str, note_type: str, context: Dict[str, Any] = None) -> Dict[str, Any]:
        """
        根据内容和笔记类型规划下一步行动
        
        Args:
            content: 待处理内容
            note_type: 笔记类型（outline/qa/full）
            context: 上下文信息
            
        Returns:
            包含action和参数的字典
        """
        system_prompt = self._build_system_prompt(note_type)
        user_prompt = self._build_user_prompt(content, context)

        messages = [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt}
        ]

        response = await self.llm.chat(messages)
        return self._parse_response(response["content"])

    def _build_system_prompt(self, note_type: str) -> str:
        prompts = {
            "outline": "你是一个笔记提取专家。请从给定内容中提取关键信息，生成结构化的大纲格式笔记。",
            "qa": "你是一个笔记提取专家。请从给定内容中提取关键信息，生成问答对形式的笔记。",
            "full": "你是一个笔记提取专家。请从给定内容中提取关键信息，生成完整的笔记，包含摘要、要点和重点标记。"
        }
        return prompts.get(note_type, prompts["full"])

    def _build_user_prompt(self, content: str, context: Dict[str, Any] = None) -> str:
        prompt = f"请处理以下内容并生成笔记：\n\n{content}"
        if context:
            prompt += f"\n\n之前的处理结果：\n{context.get('previous_results', '')}"
        return prompt

    def _parse_response(self, response: str) -> Dict[str, Any]:
        import json
        try:
            return json.loads(response)
        except json.JSONDecodeError:
            return {"action": "finish", "result": response}
```

- [ ] **Step 4: 创建反思模块backend/app/agent/reflector.py**

```python
from typing import Dict, Any
from app.llm.base import LLMProvider


class Reflector:
    """Agent反思模块"""

    def __init__(self, llm: LLMProvider):
        self.llm = llm

    async def reflect(self, content: str, generated_note: str) -> Dict[str, Any]:
        """
        评估生成的笔记质量
        
        Args:
            content: 原始内容
            generated_note: 生成的笔记
            
        Returns:
            包含评估结果和建议的字典
        """
        prompt = f"""请评估以下笔记的质量：

原始内容：
{content[:1000]}...

生成的笔记：
{generated_note}

请评估：
1. 是否遗漏了重要信息？
2. 结构是否清晰？
3. 是否需要补充？

请用JSON格式返回：{{"quality": "high/medium/low", "missing": [], "suggestions": [], "should_continue": true/false}}"""

        messages = [
            {"role": "system", "content": "你是一个笔记质量评估专家。"},
            {"role": "user", "content": prompt}
        ]

        response = await self.llm.chat(messages)
        
        import json
        try:
            return json.loads(response["content"])
        except json.JSONDecodeError:
            return {
                "quality": "medium",
                "missing": [],
                "suggestions": [],
                "should_continue": False
            }
```

- [ ] **Step 5: 创建Agent引擎backend/app/agent/engine.py**

```python
from typing import Dict, Any, Optional
from app.llm.base import LLMProvider
from app.agent.planner import Planner
from app.agent.reflector import Reflector
from app.tools.registry import ToolRegistry


class AgentEngine:
    """Agent引擎 - ReAct循环实现"""

    def __init__(self, llm: LLMProvider, max_steps: int = 10):
        self.llm = llm
        self.planner = Planner(llm)
        self.reflector = Reflector(llm)
        self.tool_registry = ToolRegistry()
        self.max_steps = max_steps

    async def run(self, content: str, note_type: str, source_type: str = "text") -> Dict[str, Any]:
        """
        执行Agent循环
        
        Args:
            content: 输入内容
            note_type: 笔记类型
            source_type: 来源类型
            
        Returns:
            包含生成笔记和执行步骤的字典
        """
        steps = []
        context = {"previous_results": ""}
        
        # 预处理：根据来源类型解析内容
        if source_type == "pdf":
            processed_content = self.tool_registry.execute("parse_pdf", file_path=content)
        elif source_type == "web":
            processed_content = self.tool_registry.execute("scrape_web", url=content)
        else:
            processed_content = self.tool_registry.execute("process_text", text=content)

        # 分块处理长文本
        if len(processed_content) > 2000:
            chunks = self.tool_registry.execute("split_text_chunks", text=processed_content)
        else:
            chunks = [processed_content]

        all_notes = []

        for i, chunk in enumerate(chunks):
            step_result = await self._process_chunk(chunk, note_type, context, i)
            steps.append(step_result)
            all_notes.append(step_result["result"])
            context["previous_results"] += f"\n\n{step_result['result']}"

        # 合并所有笔记
        final_note = self.tool_registry.execute("merge_chunks", chunks=all_notes)

        # 反思检查
        reflection = await self.reflector.reflect(processed_content, final_note)
        steps.append({"step": "reflection", "result": reflection})

        # 如果需要补充，再处理一次
        if reflection.get("should_continue", False) and len(steps) < self.max_steps:
            additional_note = await self._handle_missing(content, final_note, reflection, note_type)
            final_note += f"\n\n## 补充内容\n\n{additional_note}"

        return {
            "content": final_note,
            "steps": steps,
            "metadata": {
                "source_type": source_type,
                "note_type": note_type,
                "chunks_processed": len(chunks)
            }
        }

    async def _process_chunk(self, chunk: str, note_type: str, context: Dict[str, Any], chunk_index: int) -> Dict[str, Any]:
        """处理单个文本块"""
        plan = await self.planner.plan(chunk, note_type, context)
        
        return {
            "step": chunk_index,
            "action": plan.get("action", "generate"),
            "result": plan.get("result", "")
        }

    async def _handle_missing(self, content: str, current_note: str, reflection: Dict[str, Any], note_type: str) -> str:
        """处理反思中发现的遗漏"""
        missing_info = reflection.get("missing", [])
        suggestions = reflection.get("suggestions", [])
        
        prompt = f"请补充以下信息到笔记中：\n遗漏：{missing_info}\n建议：{suggestions}"
        
        messages = [
            {"role": "system", "content": "你是一个笔记补充专家。"},
            {"role": "user", "content": prompt}
        ]
        
        response = await self.llm.chat(messages)
        return response["content"]
```

- [ ] **Step 6: 创建__init__.py文件backend/app/agent/__init__.py**

```python
from app.agent.engine import AgentEngine

__all__ = ["AgentEngine"]
```

- [ ] **Step 7: 运行测试验证通过**

Run: `cd backend && python -m pytest tests/test_agent.py -v`
Expected: 2 tests passed

- [ ] **Step 8: Commit**

```bash
git add backend/app/agent/ backend/tests/test_agent.py
git commit -m "feat: implement Agent engine with ReAct loop"
```

---

## Task 9: API路由实现

**Files:**
- Create: `backend/app/api/__init__.py`
- Create: `backend/app/api/notes.py`
- Create: `backend/app/api/tasks.py`
- Create: `backend/app/services/__init__.py`
- Create: `backend/app/services/note_service.py`
- Create: `backend/app/services/task_service.py`
- Modify: `backend/app/main.py`

- [ ] **Step 1: 创建笔记服务backend/app/services/note_service.py**

```python
from typing import List, Optional
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from app.models.note import Note, NoteType, SourceType
import uuid


class NoteService:
    """笔记服务"""

    def __init__(self, db: AsyncSession):
        self.db = db

    async def create_note(
        self,
        title: str,
        source_type: SourceType,
        content_raw: str,
        content_markdown: str,
        note_type: NoteType,
        source_url: Optional[str] = None
    ) -> Note:
        note = Note(
            id=str(uuid.uuid4()),
            title=title,
            source_type=source_type,
            source_url=source_url,
            content_raw=content_raw,
            content_markdown=content_markdown,
            note_type=note_type
        )
        self.db.add(note)
        await self.db.commit()
        await self.db.refresh(note)
        return note

    async def get_note(self, note_id: str) -> Optional[Note]:
        result = await self.db.execute(select(Note).where(Note.id == note_id))
        return result.scalar_one_or_none()

    async def get_notes(self, skip: int = 0, limit: int = 100) -> List[Note]:
        result = await self.db.execute(select(Note).offset(skip).limit(limit))
        return list(result.scalars().all())

    async def update_note(self, note_id: str, **kwargs) -> Optional[Note]:
        note = await self.get_note(note_id)
        if note:
            for key, value in kwargs.items():
                setattr(note, key, value)
            await self.db.commit()
            await self.db.refresh(note)
        return note

    async def delete_note(self, note_id: str) -> bool:
        note = await self.get_note(note_id)
        if note:
            await self.db.delete(note)
            await self.db.commit()
            return True
        return False
```

- [ ] **Step 2: 创建任务服务backend/app/services/task_service.py**

```python
from typing import Optional
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from app.models.task import Task, TaskStatus
import uuid


class TaskService:
    """任务服务"""

    def __init__(self, db: AsyncSession):
        self.db = db

    async def create_task(self, note_id: Optional[str] = None) -> Task:
        task = Task(
            id=str(uuid.uuid4()),
            note_id=note_id,
            status=TaskStatus.PENDING
        )
        self.db.add(task)
        await self.db.commit()
        await self.db.refresh(task)
        return task

    async def get_task(self, task_id: str) -> Optional[Task]:
        result = await self.db.execute(select(Task).where(Task.id == task_id))
        return result.scalar_one_or_none()

    async def update_task_status(self, task_id: str, status: TaskStatus, steps: list = None, result: str = None) -> Optional[Task]:
        task = await self.get_task(task_id)
        if task:
            task.status = status
            if steps is not None:
                task.steps = steps
            if result is not None:
                task.result = result
            await self.db.commit()
            await self.db.refresh(task)
        return task
```

- [ ] **Step 3: 创建笔记API路由backend/app/api/notes.py**

```python
from fastapi import APIRouter, Depends, HTTPException, UploadFile, File, Form
from sqlalchemy.ext.asyncio import AsyncSession
from typing import Optional
from app.database import get_db
from app.models.note import NoteType, SourceType
from app.services.note_service import NoteService
from app.agent.engine import AgentEngine
from app.llm.qwen import QwenProvider
from app.config import get_settings
import tempfile
import os

router = APIRouter(prefix="/api/notes", tags=["notes"])


def get_agent_engine():
    settings = get_settings()
    llm = QwenProvider(api_key=settings.qwen_api_key, model=settings.qwen_model)
    return AgentEngine(llm=llm)


@router.post("/upload")
async def upload_file(
    file: UploadFile = File(...),
    note_type: NoteType = Form(NoteType.FULL),
    db: AsyncSession = Depends(get_db)
):
    """上传文件生成笔记"""
    # 保存上传的文件
    with tempfile.NamedTemporaryFile(delete=False, suffix=".pdf") as tmp:
        content = await file.read()
        tmp.write(content)
        tmp_path = tmp.name

    try:
        engine = get_agent_engine()
        result = await engine.run(
            content=tmp_path,
            note_type=note_type.value,
            source_type="pdf"
        )
        
        note_service = NoteService(db)
        note = await note_service.create_note(
            title=file.filename,
            source_type=SourceType.PDF,
            content_raw=content.decode("utf-8", errors="ignore"),
            content_markdown=result["content"],
            note_type=note_type
        )
        
        return {"note_id": note.id, "status": "completed", "content": result["content"]}
    finally:
        os.unlink(tmp_path)


@router.post("/from-url")
async def create_from_url(
    url: str,
    note_type: NoteType = NoteType.FULL,
    db: AsyncSession = Depends(get_db)
):
    """从URL生成笔记"""
    engine = get_agent_engine()
    result = await engine.run(
        content=url,
        note_type=note_type.value,
        source_type="web"
    )
    
    note_service = NoteService(db)
    note = await note_service.create_note(
        title=url,
        source_type=SourceType.WEB,
        content_raw=url,
        content_markdown=result["content"],
        note_type=note_type,
        source_url=url
    )
    
    return {"note_id": note.id, "status": "completed", "content": result["content"]}


@router.post("/from-text")
async def create_from_text(
    text: str,
    title: str = "Untitled",
    note_type: NoteType = NoteType.FULL,
    db: AsyncSession = Depends(get_db)
):
    """从文本生成笔记"""
    engine = get_agent_engine()
    result = await engine.run(
        content=text,
        note_type=note_type.value,
        source_type="text"
    )
    
    note_service = NoteService(db)
    note = await note_service.create_note(
        title=title,
        source_type=SourceType.TEXT,
        content_raw=text,
        content_markdown=result["content"],
        note_type=note_type
    )
    
    return {"note_id": note.id, "status": "completed", "content": result["content"]}


@router.get("/")
async def list_notes(skip: int = 0, limit: int = 100, db: AsyncSession = Depends(get_db)):
    """获取笔记列表"""
    note_service = NoteService(db)
    notes = await note_service.get_notes(skip=skip, limit=limit)
    return [
        {
            "id": note.id,
            "title": note.title,
            "source_type": note.source_type,
            "note_type": note.note_type,
            "created_at": note.created_at
        }
        for note in notes
    ]


@router.get("/{note_id}")
async def get_note(note_id: str, db: AsyncSession = Depends(get_db)):
    """获取单个笔记"""
    note_service = NoteService(db)
    note = await note_service.get_note(note_id)
    if not note:
        raise HTTPException(status_code=404, detail="Note not found")
    return {
        "id": note.id,
        "title": note.title,
        "source_type": note.source_type,
        "source_url": note.source_url,
        "content_raw": note.content_raw,
        "content_markdown": note.content_markdown,
        "note_type": note.note_type,
        "created_at": note.created_at,
        "updated_at": note.updated_at
    }


@router.put("/{note_id}")
async def update_note(note_id: str, content_markdown: str, db: AsyncSession = Depends(get_db)):
    """编辑笔记"""
    note_service = NoteService(db)
    note = await note_service.update_note(note_id, content_markdown=content_markdown)
    if not note:
        raise HTTPException(status_code=404, detail="Note not found")
    return {"id": note.id, "status": "updated"}


@router.delete("/{note_id}")
async def delete_note(note_id: str, db: AsyncSession = Depends(get_db)):
    """删除笔记"""
    note_service = NoteService(db)
    success = await note_service.delete_note(note_id)
    if not success:
        raise HTTPException(status_code=404, detail="Note not found")
    return {"status": "deleted"}


@router.get("/{note_id}/export")
async def export_note(note_id: str, format: str = "markdown", db: AsyncSession = Depends(get_db)):
    """导出笔记"""
    note_service = NoteService(db)
    note = await note_service.get_note(note_id)
    if not note:
        raise HTTPException(status_code=404, detail="Note not found")
    
    if format == "markdown":
        return {"content": note.content_markdown, "filename": f"{note.title}.md"}
    else:
        raise HTTPException(status_code=400, detail="Unsupported format")
```

- [ ] **Step 4: 创建任务API路由backend/app/api/tasks.py**

```python
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from app.database import get_db
from app.services.task_service import TaskService

router = APIRouter(prefix="/api/tasks", tags=["tasks"])


@router.get("/{task_id}")
async def get_task(task_id: str, db: AsyncSession = Depends(get_db)):
    """查询Agent任务状态"""
    task_service = TaskService(db)
    task = await task_service.get_task(task_id)
    if not task:
        raise HTTPException(status_code=404, detail="Task not found")
    return {
        "id": task.id,
        "note_id": task.note_id,
        "status": task.status,
        "steps": task.steps,
        "result": task.result,
        "created_at": task.created_at
    }
```

- [ ] **Step 5: 更新main.py注册路由**

修改 `backend/app/main.py`:

```python
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from contextlib import asynccontextmanager
from app.database import init_db
from app.api.notes import router as notes_router
from app.api.tasks import router as tasks_router


@asynccontextmanager
async def lifespan(app: FastAPI):
    await init_db()
    yield


app = FastAPI(title="Agent Note Extraction", lifespan=lifespan)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:3000"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(notes_router)
app.include_router(tasks_router)


@app.get("/")
async def root():
    return {"message": "Agent Note Extraction API"}
```

- [ ] **Step 6: 创建services/__init__.py**

```python
from app.services.note_service import NoteService
from app.services.task_service import TaskService

__all__ = ["NoteService", "TaskService"]
```

- [ ] **Step 7: 创建api/__init__.py**

```python
from app.api.notes import router as notes_router
from app.api.tasks import router as tasks_router

__all__ = ["notes_router", "tasks_router"]
```

- [ ] **Step 8: 运行测试验证API**

```bash
cd backend && python -m pytest tests/test_notes_api.py -v
```

- [ ] **Step 9: Commit**

```bash
git add backend/app/api/ backend/app/services/
git commit -m "feat: implement API routes for notes and tasks"
```

---

## Task 10: 前端项目初始化

**Files:**
- Create: `frontend/package.json`
- Create: `frontend/tsconfig.json`
- Create: `frontend/public/index.html`
- Create: `frontend/src/index.tsx`
- Create: `frontend/src/App.tsx`
- Create: `frontend/src/api/client.ts`

- [ ] **Step 1: 创建package.json**

```json
{
  "name": "agent-note-extraction-frontend",
  "version": "1.0.0",
  "private": true,
  "dependencies": {
    "react": "^18.2.0",
    "react-dom": "^18.2.0",
    "react-router-dom": "^6.21.0",
    "antd": "^5.12.0",
    "axios": "^1.6.2",
    "react-markdown": "^9.0.1",
    "typescript": "^5.3.3",
    "@types/react": "^18.2.45",
    "@types/react-dom": "^18.2.18",
    "react-scripts": "5.0.1"
  },
  "scripts": {
    "start": "react-scripts start",
    "build": "react-scripts build",
    "test": "react-scripts test"
  },
  "browserslist": {
    "production": [">0.2%", "not dead", "not op_mini all"],
    "development": ["last 1 chrome version", "last 1 firefox version", "last 1 safari version"]
  }
}
```

- [ ] **Step 2: 创建tsconfig.json**

```json
{
  "compilerOptions": {
    "target": "es5",
    "lib": ["dom", "dom.iterable", "esnext"],
    "allowJs": true,
    "skipLibCheck": true,
    "esModuleInterop": true,
    "allowSyntheticDefaultImports": true,
    "strict": true,
    "forceConsistentCasingInFileNames": true,
    "noFallthroughCasesInSwitch": true,
    "module": "esnext",
    "moduleResolution": "node",
    "resolveJsonModule": true,
    "isolatedModules": true,
    "noEmit": true,
    "jsx": "react-jsx"
  },
  "include": ["src"]
}
```

- [ ] **Step 3: 创建public/index.html**

```html
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Agent Note Extraction</title>
</head>
<body>
    <div id="root"></div>
</body>
</html>
```

- [ ] **Step 4: 创建API客户端frontend/src/api/client.ts**

```typescript
import axios from 'axios';

const apiClient = axios.create({
  baseURL: 'http://localhost:8000',
  headers: {
    'Content-Type': 'application/json',
  },
});

export interface Note {
  id: string;
  title: string;
  source_type: 'pdf' | 'web' | 'text';
  source_url?: string;
  content_raw: string;
  content_markdown: string;
  note_type: 'outline' | 'qa' | 'full';
  created_at: string;
  updated_at: string;
}

export interface Task {
  id: string;
  note_id?: string;
  status: 'pending' | 'running' | 'completed' | 'failed';
  steps: any[];
  result?: string;
  created_at: string;
}

export const noteApi = {
  upload: (file: File, noteType: string) => {
    const formData = new FormData();
    formData.append('file', file);
    formData.append('note_type', noteType);
    return apiClient.post('/api/notes/upload', formData);
  },
  
  fromUrl: (url: string, noteType: string) => {
    return apiClient.post('/api/notes/from-url', null, { params: { url, note_type: noteType } });
  },
  
  fromText: (text: string, title: string, noteType: string) => {
    return apiClient.post('/api/notes/from-text', null, { params: { text, title, note_type: noteType } });
  },
  
  list: (skip = 0, limit = 100) => {
    return apiClient.get<Note[]>('/api/notes/', { params: { skip, limit } });
  },
  
  get: (id: string) => {
    return apiClient.get<Note>(`/api/notes/${id}`);
  },
  
  update: (id: string, content: string) => {
    return apiClient.put(`/api/notes/${id}`, null, { params: { content_markdown: content } });
  },
  
  delete: (id: string) => {
    return apiClient.delete(`/api/notes/${id}`);
  },
  
  export: (id: string, format = 'markdown') => {
    return apiClient.get(`/api/notes/${id}/export`, { params: { format } });
  },
};

export const taskApi = {
  get: (id: string) => {
    return apiClient.get<Task>(`/api/tasks/${id}`);
  },
};

export default apiClient;
```

- [ ] **Step 5: 创建入口文件frontend/src/index.tsx**

```typescript
import React from 'react';
import ReactDOM from 'react-dom/client';
import App from './App';

const root = ReactDOM.createRoot(
  document.getElementById('root') as HTMLElement
);
root.render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);
```

- [ ] **Step 6: 创建App组件frontend/src/App.tsx**

```typescript
import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { Layout, Menu } from 'antd';
import { HomeOutlined, FileTextOutlined, UnorderedListOutlined } from '@ant-design/icons';
import HomePage from './pages/HomePage';
import NoteListPage from './pages/NoteListPage';
import NoteDetailPage from './pages/NoteDetailPage';

const { Header, Content, Footer } = Layout;

const App: React.FC = () => {
  return (
    <Router>
      <Layout style={{ minHeight: '100vh' }}>
        <Header style={{ display: 'flex', alignItems: 'center' }}>
          <div style={{ color: 'white', fontSize: '18px', fontWeight: 'bold', marginRight: '40px' }}>
            Agent Note Extraction
          </div>
          <Menu
            theme="dark"
            mode="horizontal"
            defaultSelectedKeys={['home']}
            items={[
              { key: 'home', icon: <HomeOutlined />, label: '首页' },
              { key: 'notes', icon: <UnorderedListOutlined />, label: '笔记列表' },
            ]}
            onClick={({ key }) => {
              window.location.href = key === 'home' ? '/' : '/notes';
            }}
          />
        </Header>
        <Content style={{ padding: '24px 50px' }}>
          <Routes>
            <Route path="/" element={<HomePage />} />
            <Route path="/notes" element={<NoteListPage />} />
            <Route path="/notes/:id" element={<NoteDetailPage />} />
          </Routes>
        </Content>
        <Footer style={{ textAlign: 'center' }}>
          Agent Note Extraction System ©2024
        </Footer>
      </Layout>
    </Router>
  );
};

export default App;
```

- [ ] **Step 7: 安装依赖并启动**

```bash
cd frontend && npm install && npm start
```

- [ ] **Step 8: Commit**

```bash
git add frontend/
git commit -m "feat: initialize frontend React project"
```

---

## Task 11: 前端首页实现

**Files:**
- Create: `frontend/src/pages/HomePage.tsx`
- Create: `frontend/src/components/FileUpload.tsx`

- [ ] **Step 1: 创建文件上传组件frontend/src/components/FileUpload.tsx**

```typescript
import React, { useState } from 'react';
import { Upload, Button, Select, message } from 'antd';
import { UploadOutlined, LinkOutlined, FileTextOutlined } from '@ant-design/icons';
import { noteApi } from '../api/client';

const { Option } = Select;

interface FileUploadProps {
  onSuccess: (noteId: string) => void;
}

const FileUpload: React.FC<FileUploadProps> = ({ onSuccess }) => {
  const [noteType, setNoteType] = useState<string>('full');
  const [url, setUrl] = useState<string>('');
  const [text, setText] = useState<string>('');
  const [loading, setLoading] = useState<boolean>(false);
  const [inputMode, setInputMode] = useState<'file' | 'url' | 'text'>('file');

  const handleFileUpload = async (file: File) => {
    setLoading(true);
    try {
      const response = await noteApi.upload(file, noteType);
      message.success('笔记生成成功！');
      onSuccess(response.data.note_id);
    } catch (error) {
      message.error('上传失败，请重试');
    } finally {
      setLoading(false);
    }
  };

  const handleUrlSubmit = async () => {
    if (!url.trim()) {
      message.warning('请输入URL');
      return;
    }
    setLoading(true);
    try {
      const response = await noteApi.fromUrl(url, noteType);
      message.success('笔记生成成功！');
      onSuccess(response.data.note_id);
    } catch (error) {
      message.error('处理失败，请重试');
    } finally {
      setLoading(false);
    }
  };

  const handleTextSubmit = async () => {
    if (!text.trim()) {
      message.warning('请输入文本内容');
      return;
    }
    setLoading(true);
    try {
      const response = await noteApi.fromText(text, '未命名笔记', noteType);
      message.success('笔记生成成功！');
      onSuccess(response.data.note_id);
    } catch (error) {
      message.error('处理失败，请重试');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div style={{ padding: '24px', background: '#fff', borderRadius: '8px' }}>
      <div style={{ marginBottom: '16px' }}>
        <Select
          value={noteType}
          onChange={setNoteType}
          style={{ width: 200, marginRight: 16 }}
        >
          <Option value="outline">大纲笔记</Option>
          <Option value="qa">问答卡片</Option>
          <Option value="full">完整笔记</Option>
        </Select>

        <Select
          value={inputMode}
          onChange={setInputMode}
          style={{ width: 200 }}
        >
          <Option value="file"><UploadOutlined /> 上传文件</Option>
          <Option value="url"><LinkOutlined /> 输入URL</Option>
          <Option value="text"><FileTextOutlined /> 输入文本</Option>
        </Select>
      </div>

      {inputMode === 'file' && (
        <Upload
          accept=".pdf,.txt,.md"
          showUploadList={false}
          beforeUpload={(file) => {
            handleFileUpload(file);
            return false;
          }}
        >
          <Button icon={<UploadOutlined />} loading={loading}>
            选择文件上传
          </Button>
        </Upload>
      )}

      {inputMode === 'url' && (
        <div>
          <input
            type="text"
            value={url}
            onChange={(e) => setUrl(e.target.value)}
            placeholder="输入网页URL"
            style={{ width: '100%', padding: '8px', marginBottom: '8px', border: '1px solid #d9d9d9', borderRadius: '4px' }}
          />
          <Button type="primary" onClick={handleUrlSubmit} loading={loading}>
            生成笔记
          </Button>
        </div>
      )}

      {inputMode === 'text' && (
        <div>
          <textarea
            value={text}
            onChange={(e) => setText(e.target.value)}
            placeholder="粘贴文本内容"
            rows={6}
            style={{ width: '100%', padding: '8px', marginBottom: '8px', border: '1px solid #d9d9d9', borderRadius: '4px' }}
          />
          <Button type="primary" onClick={handleTextSubmit} loading={loading}>
            生成笔记
          </Button>
        </div>
      )}
    </div>
  );
};

export default FileUpload;
```

- [ ] **Step 2: 创建首页frontend/src/pages/HomePage.tsx**

```typescript
import React from 'react';
import { useNavigate } from 'react-router-dom';
import { Typography, Card } from 'antd';
import FileUpload from '../components/FileUpload';

const { Title, Paragraph } = Typography;

const HomePage: React.FC = () => {
  const navigate = useNavigate();

  const handleSuccess = (noteId: string) => {
    navigate(`/notes/${noteId}`);
  };

  return (
    <div style={{ maxWidth: 800, margin: '0 auto' }}>
      <Typography>
        <Title level={2}>Agent驱动的自动笔记提取</Title>
        <Paragraph>
          上传PDF文件、输入网页URL或粘贴文本，AI Agent将自动提取关键信息并生成结构化笔记。
        </Paragraph>
      </Typography>
      
      <Card title="生成笔记" style={{ marginTop: 24 }}>
        <FileUpload onSuccess={handleSuccess} />
      </Card>
    </div>
  );
};

export default HomePage;
```

- [ ] **Step 3: 测试首页功能**

```bash
cd frontend && npm start
```
访问 http://localhost:3000 验证页面正常显示

- [ ] **Step 4: Commit**

```bash
git add frontend/src/pages/HomePage.tsx frontend/src/components/FileUpload.tsx
git commit -m "feat: implement home page with file upload"
```

---

## Task 12: 前端笔记列表页实现

**Files:**
- Create: `frontend/src/pages/NoteListPage.tsx`

- [ ] **Step 1: 创建笔记列表页frontend/src/pages/NoteListPage.tsx**

```typescript
import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Table, Tag, Button, message, Popconfirm } from 'antd';
import { EyeOutlined, DeleteOutlined } from '@ant-design/icons';
import { noteApi, Note } from '../api/client';

const NoteListPage: React.FC = () => {
  const navigate = useNavigate();
  const [notes, setNotes] = useState<Note[]>([]);
  const [loading, setLoading] = useState<boolean>(false);

  const fetchNotes = async () => {
    setLoading(true);
    try {
      const response = await noteApi.list();
      setNotes(response.data);
    } catch (error) {
      message.error('获取笔记列表失败');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchNotes();
  }, []);

  const handleDelete = async (id: string) => {
    try {
      await noteApi.delete(id);
      message.success('删除成功');
      fetchNotes();
    } catch (error) {
      message.error('删除失败');
    }
  };

  const columns = [
    {
      title: '标题',
      dataIndex: 'title',
      key: 'title',
      render: (text: string, record: Note) => (
        <a onClick={() => navigate(`/notes/${record.id}`)}>{text}</a>
      ),
    },
    {
      title: '来源',
      dataIndex: 'source_type',
      key: 'source_type',
      render: (type: string) => {
        const colorMap: Record<string, string> = {
          pdf: 'blue',
          web: 'green',
          text: 'orange',
        };
        return <Tag color={colorMap[type]}>{type.toUpperCase()}</Tag>;
      },
    },
    {
      title: '笔记类型',
      dataIndex: 'note_type',
      key: 'note_type',
      render: (type: string) => {
        const labelMap: Record<string, string> = {
          outline: '大纲',
          qa: '问答',
          full: '完整',
        };
        return <Tag>{labelMap[type]}</Tag>;
      },
    },
    {
      title: '创建时间',
      dataIndex: 'created_at',
      key: 'created_at',
      render: (date: string) => new Date(date).toLocaleString(),
    },
    {
      title: '操作',
      key: 'action',
      render: (_: any, record: Note) => (
        <>
          <Button
            type="link"
            icon={<EyeOutlined />}
            onClick={() => navigate(`/notes/${record.id}`)}
          >
            查看
          </Button>
          <Popconfirm
            title="确定删除此笔记？"
            onConfirm={() => handleDelete(record.id)}
            okText="确定"
            cancelText="取消"
          >
            <Button type="link" danger icon={<DeleteOutlined />}>
              删除
            </Button>
          </Popconfirm>
        </>
      ),
    },
  ];

  return (
    <div>
      <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 16 }}>
        <h2>笔记列表</h2>
        <Button type="primary" onClick={() => navigate('/')}>
          新建笔记
        </Button>
      </div>
      <Table
        columns={columns}
        dataSource={notes}
        rowKey="id"
        loading={loading}
      />
    </div>
  );
};

export default NoteListPage;
```

- [ ] **Step 2: 测试笔记列表页**

```bash
cd frontend && npm start
```
访问 http://localhost:3000/notes 验证页面正常显示

- [ ] **Step 3: Commit**

```bash
git add frontend/src/pages/NoteListPage.tsx
git commit -m "feat: implement note list page"
```

---

## Task 13: 前端笔记详情页实现

**Files:**
- Create: `frontend/src/pages/NoteDetailPage.tsx`
- Create: `frontend/src/components/NoteEditor.tsx`
- Create: `frontend/src/components/NoteViewer.tsx`

- [ ] **Step 1: 创建笔记查看组件frontend/src/components/NoteViewer.tsx**

```typescript
import React from 'react';
import ReactMarkdown from 'react-markdown';

interface NoteViewerProps {
  content: string;
}

const NoteViewer: React.FC<NoteViewerProps> = ({ content }) => {
  return (
    <div style={{ padding: '24px', background: '#fff', borderRadius: '8px' }}>
      <ReactMarkdown>{content}</ReactMarkdown>
    </div>
  );
};

export default NoteViewer;
```

- [ ] **Step 2: 创建笔记编辑组件frontend/src/components/NoteEditor.tsx**

```typescript
import React, { useState } from 'react';
import { Button, message } from 'antd';
import { SaveOutlined } from '@ant-design/icons';
import { noteApi } from '../api/client';

interface NoteEditorProps {
  noteId: string;
  initialContent: string;
  onSave: (content: string) => void;
}

const NoteEditor: React.FC<NoteEditorProps> = ({ noteId, initialContent, onSave }) => {
  const [content, setContent] = useState<string>(initialContent);
  const [saving, setSaving] = useState<boolean>(false);

  const handleSave = async () => {
    setSaving(true);
    try {
      await noteApi.update(noteId, content);
      message.success('保存成功');
      onSave(content);
    } catch (error) {
      message.error('保存失败');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div>
      <textarea
        value={content}
        onChange={(e) => setContent(e.target.value)}
        style={{
          width: '100%',
          minHeight: '400px',
          padding: '16px',
          fontFamily: 'monospace',
          fontSize: '14px',
          border: '1px solid #d9d9d9',
          borderRadius: '4px',
        }}
      />
      <div style={{ marginTop: '16px' }}>
        <Button
          type="primary"
          icon={<SaveOutlined />}
          onClick={handleSave}
          loading={saving}
        >
          保存
        </Button>
      </div>
    </div>
  );
};

export default NoteEditor;
```

- [ ] **Step 3: 创建笔记详情页frontend/src/pages/NoteDetailPage.tsx**

```typescript
import React, { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { Card, Button, message, Spin, Tabs } from 'antd';
import { EditOutlined, EyeOutlined, DownloadOutlined, ArrowLeftOutlined } from '@ant-design/icons';
import { noteApi, Note } from '../api/client';
import NoteViewer from '../components/NoteViewer';
import NoteEditor from '../components/NoteEditor';

const NoteDetailPage: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const [note, setNote] = useState<Note | null>(null);
  const [loading, setLoading] = useState<boolean>(false);
  const [editing, setEditing] = useState<boolean>(false);

  const fetchNote = async () => {
    if (!id) return;
    setLoading(true);
    try {
      const response = await noteApi.get(id);
      setNote(response.data);
    } catch (error) {
      message.error('获取笔记失败');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchNote();
  }, [id]);

  const handleExport = async () => {
    if (!id) return;
    try {
      const response = await noteApi.export(id);
      const blob = new Blob([response.data.content], { type: 'text/markdown' });
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = response.data.filename || 'note.md';
      a.click();
      window.URL.revokeObjectURL(url);
    } catch (error) {
      message.error('导出失败');
    }
  };

  const handleSave = (content: string) => {
    if (note) {
      setNote({ ...note, content_markdown: content });
    }
    setEditing(false);
  };

  if (loading) {
    return <Spin size="large" style={{ display: 'block', margin: '100px auto' }} />;
  }

  if (!note) {
    return <div>笔记不存在</div>;
  }

  return (
    <div style={{ maxWidth: 1000, margin: '0 auto' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 16 }}>
        <Button icon={<ArrowLeftOutlined />} onClick={() => navigate('/notes')}>
          返回列表
        </Button>
        <div>
          <Button
            icon={<EditOutlined />}
            onClick={() => setEditing(!editing)}
            style={{ marginRight: 8 }}
          >
            {editing ? '取消编辑' : '编辑'}
          </Button>
          <Button icon={<DownloadOutlined />} onClick={handleExport}>
            导出
          </Button>
        </div>
      </div>

      <Card title={note.title}>
        {editing ? (
          <NoteEditor
            noteId={note.id}
            initialContent={note.content_markdown}
            onSave={handleSave}
          />
        ) : (
          <NoteViewer content={note.content_markdown} />
        )}
      </Card>
    </div>
  );
};

export default NoteDetailPage;
```

- [ ] **Step 4: 测试笔记详情页**

```bash
cd frontend && npm start
```
访问 http://localhost:3000/notes/test-id 验证页面正常显示

- [ ] **Step 5: Commit**

```bash
git add frontend/src/pages/NoteDetailPage.tsx frontend/src/components/NoteEditor.tsx frontend/src/components/NoteViewer.tsx
git commit -m "feat: implement note detail page with edit and export"
```

---

## Task 14: 集成测试与调试

**Files:**
- Create: `backend/tests/test_integration.py`
- Modify: `backend/requirements.txt` (if needed)

- [ ] **Step 1: 创建集成测试backend/tests/test_integration.py**

```python
import pytest
from fastapi.testclient import TestClient
from app.main import app
from app.database import init_db
import asyncio


@pytest.fixture(scope="module")
def client():
    # 初始化数据库
    asyncio.run(init_db())
    return TestClient(app)


def test_root_endpoint(client):
    response = client.get("/")
    assert response.status_code == 200
    assert response.json()["message"] == "Agent Note Extraction API"


def test_create_note_from_text(client):
    response = client.post(
        "/api/notes/from-text",
        params={
            "text": "这是一段测试文本内容",
            "title": "测试笔记",
            "note_type": "outline"
        }
    )
    # 注意：这个测试需要有效的API key才能通过
    # assert response.status_code == 200
    # assert "note_id" in response.json()


def test_list_notes(client):
    response = client.get("/api/notes/")
    assert response.status_code == 200
    assert isinstance(response.json(), list)
```

- [ ] **Step 2: 运行集成测试**

```bash
cd backend && python -m pytest tests/test_integration.py -v
```

- [ ] **Step 3: 创建.env文件配置API Key**

```bash
cd backend && cat > .env << 'EOF'
QWEN_API_KEY=your_api_key_here
QWEN_MODEL=qwen-turbo
DATABASE_URL=sqlite+aiosqlite:///./notes.db
EOF
```

- [ ] **Step 4: 完整功能测试**

启动后端：
```bash
cd backend && uvicorn app.main:app --reload
```

启动前端：
```bash
cd frontend && npm start
```

测试流程：
1. 访问 http://localhost:3000
2. 选择笔记类型
3. 输入文本或URL
4. 生成笔记
5. 查看笔记详情
6. 编辑并保存
7. 导出Markdown

- [ ] **Step 5: Commit**

```bash
git add .
git commit -m "feat: complete integration testing and documentation"
```

---

## Task 15: 项目文档完善

**Files:**
- Create: `README.md`
- Create: `backend/README.md`
- Create: `frontend/README.md`

- [ ] **Step 1: 创建主README.md**

```markdown
# Agent驱动的自动笔记提取系统

基于智能Agent技术的自动笔记提取系统，能够从多种来源（PDF、网页、文本）自动生成结构化的笔记。

## 功能特点

- **多源输入**：支持PDF文件、网页URL、纯文本输入
- **智能提取**：Agent自动规划提取步骤，分段处理长文档
- **多种输出**：大纲笔记、问答卡片、完整笔记
- **编辑导出**：支持在线编辑和Markdown导出

## 技术栈

- **后端**：Python, FastAPI, SQLAlchemy, SQLite
- **前端**：React, TypeScript, Ant Design
- **AI**：通义千问API (可切换其他LLM)

## 快速开始

### 后端

```bash
cd backend
pip install -r requirements.txt
cp .env.example .env  # 配置API Key
uvicorn app.main:app --reload
```

### 前端

```bash
cd frontend
npm install
npm start
```

访问 http://localhost:3000

## 项目结构

```
agent/
├── backend/          # Python后端
│   ├── app/
│   │   ├── agent/    # Agent核心引擎
│   │   ├── api/      # API路由
│   │   ├── llm/      # LLM抽象层
│   │   ├── models/   # 数据模型
│   │   └── tools/    # 工具注册表
│   └── tests/
├── frontend/         # React前端
│   └── src/
│       ├── pages/
│       └── components/
└── docs/             # 文档
```

## API文档

启动后端后访问 http://localhost:8000/docs

## 开发说明

- 使用TDD方式开发
- 每个功能模块独立测试
- 支持多种LLM API切换
```

- [ ] **Step 2: 创建后端README.md**

```markdown
# 后端 - Agent Note Extraction

## 安装

```bash
pip install -r requirements.txt
```

## 配置

创建 `.env` 文件：

```env
QWEN_API_KEY=your_api_key
QWEN_MODEL=qwen-turbo
DATABASE_URL=sqlite+aiosqlite:///./notes.db
```

## 运行

```bash
uvicorn app.main:app --reload
```

## 测试

```bash
pytest tests/
```

## API

访问 http://localhost:8000/docs 查看API文档
```

- [ ] **Step 3: 创建前端README.md**

```markdown
# 前端 - Agent Note Extraction

## 安装

```bash
npm install
```

## 运行

```bash
npm start
```

访问 http://localhost:3000

## 构建

```bash
npm run build
```

## 主要页面

- `/` - 首页，上传文件或输入内容
- `/notes` - 笔记列表
- `/notes/:id` - 笔记详情
```

- [ ] **Step 4: Commit**

```bash
git add README.md backend/README.md frontend/README.md
git commit -m "docs: add project documentation"
```

---

## 自检清单

### 1. Spec覆盖检查

- ✅ 多源输入（PDF、网页、文本）
- ✅ Agent引擎（ReAct循环）
- ✅ LLM抽象层
- ✅ 工具注册机制
- ✅ 多种笔记格式（大纲、问答、完整）
- ✅ 前端页面（首页、列表、详情）
- ✅ 编辑和导出功能

### 2. 占位符检查

- ✅ 无TBD/TODO
- ✅ 所有代码完整
- ✅ 所有命令可执行

### 3. 类型一致性检查

- ✅ Note模型字段一致
- ✅ Task模型字段一致
- ✅ API接口参数一致
- ✅ 前端类型定义一致

---

## 执行选项

**计划完成并保存到 `docs/superpowers/plans/2026-06-27-agent-note-extraction.md`。两种执行方式：**

**1. Subagent-Driven（推荐）** - 每个任务分发新的子代理，任务间审查，快速迭代

**2. Inline Execution** - 在当前会话中执行任务，批量执行带检查点

**选择哪种方式？**
