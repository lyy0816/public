# Agent驱动的自动笔记提取系统 - 设计文档

## 1. 项目概述

**目标**：构建一个基于智能Agent技术的自动笔记提取系统，能够从多种来源（PDF、网页、文本）自动生成结构化的笔记。

**核心特点**：
- 自研Agent引擎，采用ReAct循环（规划→执行→反思）
- 支持多种输入源：PDF文档、网页、纯文本
- 可配置的输出格式：大纲、问答卡片、完整笔记
- 基于国内LLM API（通义千问/文心一言等）

## 2. 系统架构

```
┌─────────────────────────────────────────────┐
│                   前端 (React)               │
│  上传文件 / 输入URL → 查看笔记 → 编辑 → 导出  │
└──────────────────┬──────────────────────────┘
                   │ HTTP API
┌──────────────────▼──────────────────────────┐
│               后端 (FastAPI)                 │
│                                             │
│  ┌─────────┐  ┌──────────┐  ┌───────────┐  │
│  │ 文件处理 │  │ Agent引擎 │  │ 笔记管理  │  │
│  │  服务    │  │ (核心)    │  │  服务     │  │
│  └────┬────┘  └────┬─────┘  └───────────┘  │
│       │            │                        │
│  ┌────▼────┐  ┌────▼─────┐                 │
│  │工具注册表│  │ LLM抽象层│                 │
│  │PDF/网页 │  │ 通义千问  │                 │
│  │/文本解析 │  │ 文心等    │                 │
│  └─────────┘  └──────────┘                 │
└─────────────────────────────────────────────┘
```

## 3. Agent引擎设计

### 3.1 ReAct循环

Agent采用ReAct（Reasoning + Acting）模式：

```
┌──────────────────────────────────────┐
│           Agent 主循环               │
│                                      │
│  1. THINK（思考）                    │
│     分析当前状态，决定下一步行动      │
│     ↓                                │
│  2. ACT（执行）                      │
│     调用工具：解析PDF/抓网页/生成笔记 │
│     ↓                                │
│  3. OBSERVE（观察）                  │
│     获取工具执行结果                  │
│     ↓                                │
│  4. REFLECT（反思）                  │
│     评估结果质量，决定是否继续        │
│     └→ 不满意 → 回到步骤1补充提取    │
│     └→ 满意 → 输出最终笔记           │
└──────────────────────────────────────┘
```

### 3.2 工作流程

1. 接收用户输入（文件/URL/文本）
2. 分析内容类型，选择合适的解析工具
3. 分段处理长文档（避免超出上下文窗口）
4. 对每段内容执行：提取关键信息 → 结构化 → 检查质量
5. 合并所有段落，生成最终笔记
6. 自我反思：检查是否有遗漏，必要时补充

### 3.3 工具列表

| 工具名称 | 功能描述 |
|---------|---------|
| `parse_pdf` | 解析PDF文件，提取文本内容 |
| `scrape_web` | 抓取网页内容，过滤广告/导航 |
| `process_text` | 处理纯文本输入 |
| `generate_outline` | 生成大纲格式笔记 |
| `generate_qa` | 生成问答卡片格式笔记 |
| `generate_full_notes` | 生成完整笔记格式 |

## 4. LLM抽象层

### 4.1 统一接口

```python
from abc import ABC, abstractmethod
from typing import List, Dict, Any, AsyncIterator

class LLMProvider(ABC):
    """LLM提供者的抽象基类"""

    @abstractmethod
    async def chat(
        self,
        messages: List[Dict[str, str]],
        tools: List[Dict[str, Any]] = None
    ) -> Dict[str, Any]:
        """发送聊天请求，返回响应"""
        pass

    @abstractmethod
    async def stream_chat(
        self,
        messages: List[Dict[str, str]],
        tools: List[Dict[str, Any]] = None
    ) -> AsyncIterator[str]:
        """流式聊天请求"""
        pass
```

### 4.2 实现类

- `QwenProvider`：通义千问API
- `WenxinProvider`：文心一言API
- `OpenAIProvider`：兼容OpenAI接口的模型（如DeepSeek）

## 5. 工具注册机制

```python
from typing import Callable, Dict, Any
import functools

class ToolRegistry:
    """工具注册表"""

    _tools: Dict[str, Callable] = {}

    @classmethod
    def register(cls, name: str, description: str):
        """工具装饰器"""
        def decorator(func):
            @functools.wraps(func)
            def wrapper(*args, **kwargs):
                return func(*args, **kwargs)
            wrapper._tool_name = name
            wrapper._tool_description = description
            cls._tools[name] = wrapper
            return wrapper
        return decorator

    @classmethod
    def get_tool(cls, name: str) -> Callable:
        """获取工具"""
        return cls._tools.get(name)

    @classmethod
    def list_tools(cls) -> List[Dict[str, str]]:
        """列出所有工具"""
        return [
            {"name": name, "description": tool._tool_description}
            for name, tool in cls._tools.items()
        ]
```

## 6. 数据模型

### 6.1 Note（笔记）

```python
class Note:
    id: str              # UUID
    title: str           # 笔记标题
    source_type: str     # 来源类型：pdf/web/text
    source_url: str      # 来源URL（可选）
    content_raw: str     # 原始提取内容
    content_markdown: str # 生成的Markdown笔记
    note_type: str       # 笔记类型：outline/qa/full
    created_at: datetime # 创建时间
    updated_at: datetime # 更新时间
```

### 6.2 Task（Agent任务）

```python
class AgentStep:
    step_number: int     # 步骤编号
    action: str          # 执行的动作
    result: str          # 执行结果
    timestamp: datetime  # 时间戳

class Task:
    id: str              # UUID
    note_id: str         # 关联的笔记ID
    status: str          # 状态：pending/running/completed/failed
    steps: List[AgentStep] # 执行步骤记录
    result: str          # 最终结果
    created_at: datetime # 创建时间
```

## 7. REST API设计

### 7.1 笔记相关

| 方法 | 路径 | 描述 |
|------|------|------|
| POST | `/api/notes/upload` | 上传文件生成笔记 |
| POST | `/api/notes/from-url` | 从URL生成笔记 |
| POST | `/api/notes/from-text` | 从文本生成笔记 |
| GET | `/api/notes` | 获取笔记列表 |
| GET | `/api/notes/{id}` | 获取单个笔记 |
| PUT | `/api/notes/{id}` | 编辑笔记 |
| DELETE | `/api/notes/{id}` | 删除笔记 |
| GET | `/api/notes/{id}/export` | 导出笔记（Markdown/PDF） |

### 7.2 任务相关

| 方法 | 路径 | 描述 |
|------|------|------|
| GET | `/api/tasks/{id}` | 查询Agent任务状态 |

## 8. 前端设计

### 8.1 页面结构

1. **首页**：输入区域（上传文件/输入URL/粘贴文本）+ 笔记类型选择
2. **笔记列表**：展示所有已生成的笔记
3. **笔记详情**：Markdown渲染 + 编辑 + 导出按钮

### 8.2 技术选型

- **框架**：React + TypeScript
- **UI库**：Ant Design（中文友好）
- **Markdown渲染**：react-markdown
- **HTTP客户端**：axios

## 9. 技术栈详情

### 9.1 后端

- **框架**：FastAPI（异步、自动API文档）
- **LLM SDK**：`dashscope`（通义千问）/ `requests` 直接调用
- **PDF解析**：`pdfplumber`
- **网页抓取**：`requests` + `beautifulsoup4`
- **数据库**：SQLite（课设够用）+ SQLAlchemy
- **任务队列**：后台任务用FastAPI的BackgroundTasks

### 9.2 前端

- **框架**：React + TypeScript
- **UI库**：Ant Design
- **Markdown渲染**：react-markdown
- **HTTP客户端**：axios

## 10. 项目结构

```
agent/
├── backend/
│   ├── app/
│   │   ├── main.py              # FastAPI入口
│   │   ├── api/                 # API路由
│   │   │   ├── notes.py
│   │   │   └── tasks.py
│   │   ├── agent/               # Agent核心
│   │   │   ├── engine.py        # ReAct循环
│   │   │   ├── planner.py       # 规划模块
│   │   │   └── reflector.py     # 反思模块
│   │   ├── tools/               # 工具注册表
│   │   │   ├── registry.py
│   │   │   ├── pdf_parser.py
│   │   │   ├── web_scraper.py
│   │   │   └── text_processor.py
│   │   ├── llm/                 # LLM抽象层
│   │   │   ├── base.py
│   │   │   ├── qwen.py
│   │   │   └── openai_compat.py
│   │   ├── models/              # 数据模型
│   │   └── services/            # 业务逻辑
│   └── requirements.txt
├── frontend/
│   ├── src/
│   │   ├── pages/
│   │   ├── components/
│   │   └── services/
│   └── package.json
└── docs/
```

## 11. 关键技术点

### 11.1 长文档分段处理

- 按章节/段落切分文档
- 每段独立提取关键信息
- 最后合并生成完整笔记

### 11.2 异步任务处理

- 生成笔记是耗时操作
- 使用FastAPI的BackgroundTasks处理
- 前端轮询任务状态

### 11.3 流式输出

- LLM响应流式返回
- 提升用户体验
- 前端实时显示生成过程

## 12. 开发计划

### 阶段一：基础框架搭建
- 后端FastAPI项目初始化
- 前端React项目初始化
- 数据库模型设计

### 阶段二：Agent核心开发
- LLM抽象层实现
- 工具注册机制
- ReAct循环实现

### 阶段三：工具实现
- PDF解析工具
- 网页抓取工具
- 笔记生成工具

### 阶段四：前端开发
- 文件上传组件
- 笔记展示组件
- 编辑和导出功能

### 阶段五：集成测试
- 端到端测试
- 性能优化
- 文档完善
