import pytest
from fastapi.testclient import TestClient
from app.main import app
from app.database import init_db
import asyncio


@pytest.fixture(scope="module")
def client():
    asyncio.run(init_db())
    return TestClient(app)


def test_root_endpoint(client):
    response = client.get("/")
    assert response.status_code == 200
    assert response.json()["message"] == "Agent Note Extraction API"


def test_list_notes(client):
    response = client.get("/api/notes/")
    assert response.status_code == 200
    assert isinstance(response.json(), list)
