import pytest
from app.llm.base import LLMProvider
from app.llm.qwen import QwenProvider


def test_llm_provider_is_abstract():
    with pytest.raises(TypeError):
        LLMProvider()


def test_qwen_provider_implements_interface():
    provider = QwenProvider(api_key="test_key")
    assert isinstance(provider, LLMProvider)
    assert hasattr(provider, 'chat')
    assert hasattr(provider, 'stream_chat')
