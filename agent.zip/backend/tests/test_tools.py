import pytest
from app.tools.registry import ToolRegistry, tool


@pytest.fixture(autouse=True)
def clear_registry():
    """Clear the registry before each test for isolation."""
    ToolRegistry.clear()
    yield
    ToolRegistry.clear()


def _register_sample_tool():
    @tool(name="test_tool", description="A test tool")
    def sample_tool_func(input: str) -> str:
        return f"processed: {input}"
    return sample_tool_func


def test_tool_registration():
    _register_sample_tool()
    registry = ToolRegistry()
    tools = registry.list_tools()
    assert any(d["name"] == "test_tool" and d["description"] == "A test tool" for d in tools)


def test_tool_execution():
    _register_sample_tool()
    registry = ToolRegistry()
    result = registry.execute("test_tool", input="hello")
    assert result == "processed: hello"


def test_tool_not_found():
    registry = ToolRegistry()
    with pytest.raises(KeyError):
        registry.execute("nonexistent_tool")
