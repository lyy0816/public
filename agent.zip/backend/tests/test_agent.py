import pytest
from unittest.mock import AsyncMock, MagicMock, patch
from app.agent.engine import AgentEngine
from app.llm.base import LLMProvider
from app.tools.registry import ToolRegistry


@pytest.fixture
def mock_llm():
    llm = AsyncMock(spec=LLMProvider)
    llm.chat.return_value = {
        "content": '{"action": "finish", "result": "Test note content"}'
    }
    return llm


@pytest.fixture(autouse=True)
def setup_tools():
    """Import tools to ensure they are registered before tests run."""
    import app.tools.text_processor  # noqa: F401


def test_agent_engine_initialization(mock_llm):
    engine = AgentEngine(llm=mock_llm)
    assert engine.llm == mock_llm
    assert engine.max_steps == 10


@pytest.mark.asyncio
async def test_agent_engine_run(mock_llm):
    engine = AgentEngine(llm=mock_llm)
    result = await engine.run(
        content="Test content",
        note_type="outline"
    )
    assert result is not None
    assert "content" in result
