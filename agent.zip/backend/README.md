# 后端 - Agent Note Extraction

## 安装

```bash
pip install -r requirements.txt
```

## 配置

创建 `.env` 文件：

```env
QWEN_API_KEY=your_api_key
QWEN_MODEL=qwen-turbo
DATABASE_URL=sqlite+aiosqlite:///./notes.db
```

## 运行

```bash
uvicorn app.main:app --reload
```

## 测试

```bash
pytest tests/
```

## API

访问 http://localhost:8000/docs 查看API文档
