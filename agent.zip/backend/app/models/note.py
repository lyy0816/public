import uuid
from datetime import datetime
from sqlalchemy import Column, String, Text, DateTime, Enum
from app.database import Base
import enum


class SourceType(str, enum.Enum):
    PDF = "pdf"
    WEB = "web"
    TEXT = "text"


class NoteType(str, enum.Enum):
    OUTLINE = "outline"
    QA = "qa"
    FULL = "full"


class Note(Base):
    __tablename__ = "notes"

    id = Column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    title = Column(String, nullable=False)
    source_type = Column(Enum(SourceType), nullable=False)
    source_url = Column(String, nullable=True)
    content_raw = Column(Text, nullable=False)
    content_markdown = Column(Text, nullable=False)
    note_type = Column(Enum(NoteType), nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
