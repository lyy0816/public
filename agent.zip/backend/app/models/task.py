import uuid
from datetime import datetime
from sqlalchemy import Column, String, Text, DateTime, Enum, ForeignKey, JSON
from sqlalchemy.orm import relationship
from app.database import Base
import enum


class TaskStatus(str, enum.Enum):
    PENDING = "pending"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"


class Task(Base):
    __tablename__ = "tasks"

    id = Column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    note_id = Column(String, ForeignKey("notes.id"), nullable=True)
    status = Column(Enum(TaskStatus), default=TaskStatus.PENDING)
    steps = Column(JSON, default=list)
    result = Column(Text, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)

    note = relationship("Note", backref="tasks")
