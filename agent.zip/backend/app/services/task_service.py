from typing import Optional
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from app.models.task import Task, TaskStatus
import uuid


class TaskService:
    def __init__(self, db: AsyncSession):
        self.db = db

    async def create_task(self, note_id=None) -> Task:
        task = Task(id=str(uuid.uuid4()), note_id=note_id, status=TaskStatus.PENDING)
        self.db.add(task)
        await self.db.commit()
        await self.db.refresh(task)
        return task

    async def get_task(self, task_id: str) -> Optional[Task]:
        result = await self.db.execute(select(Task).where(Task.id == task_id))
        return result.scalar_one_or_none()

    async def update_task_status(self, task_id, status, steps=None, result=None) -> Optional[Task]:
        task = await self.get_task(task_id)
        if task:
            task.status = status
            if steps is not None: task.steps = steps
            if result is not None: task.result = result
            await self.db.commit()
            await self.db.refresh(task)
        return task
