from typing import List, Optional
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from app.models.note import Note, NoteType, SourceType
import uuid


class NoteService:
    def __init__(self, db: AsyncSession):
        self.db = db

    async def create_note(self, title, source_type, content_raw, content_markdown, note_type, source_url=None) -> Note:
        note = Note(id=str(uuid.uuid4()), title=title, source_type=source_type, source_url=source_url, content_raw=content_raw, content_markdown=content_markdown, note_type=note_type)
        self.db.add(note)
        await self.db.commit()
        await self.db.refresh(note)
        return note

    async def get_note(self, note_id: str) -> Optional[Note]:
        result = await self.db.execute(select(Note).where(Note.id == note_id))
        return result.scalar_one_or_none()

    async def get_notes(self, skip=0, limit=100) -> List[Note]:
        result = await self.db.execute(select(Note).offset(skip).limit(limit))
        return list(result.scalars().all())

    async def update_note(self, note_id, **kwargs) -> Optional[Note]:
        note = await self.get_note(note_id)
        if note:
            for key, value in kwargs.items():
                setattr(note, key, value)
            await self.db.commit()
            await self.db.refresh(note)
        return note

    async def delete_note(self, note_id) -> bool:
        note = await self.get_note(note_id)
        if note:
            await self.db.delete(note)
            await self.db.commit()
            return True
        return False
