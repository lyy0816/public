from pydantic_settings import BaseSettings
from functools import lru_cache


class Settings(BaseSettings):
    app_name: str = "Agent Note Extraction"
    database_url: str = "sqlite+aiosqlite:///./notes.db"
    qwen_api_key: str = ""
    qwen_model: str = "qwen-turbo"

    class Config:
        env_file = ".env"


@lru_cache()
def get_settings() -> Settings:
    return Settings()
