from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from app.database import get_db
from app.services.task_service import TaskService

router = APIRouter(prefix="/api/tasks", tags=["tasks"])


@router.get("/{task_id}")
async def get_task(task_id: str, db: AsyncSession = Depends(get_db)):
    task_service = TaskService(db)
    task = await task_service.get_task(task_id)
    if not task: raise HTTPException(status_code=404, detail="Task not found")
    return {"id": task.id, "note_id": task.note_id, "status": task.status, "steps": task.steps, "result": task.result, "created_at": task.created_at}
