from fastapi import APIRouter, Depends, HTTPException, UploadFile, File, Form
from sqlalchemy.ext.asyncio import AsyncSession
from app.database import get_db
from app.models.note import NoteType, SourceType
from app.services.note_service import NoteService
from app.agent.engine import AgentEngine
from app.llm.qwen import QwenProvider
from app.config import get_settings
import tempfile, os

router = APIRouter(prefix="/api/notes", tags=["notes"])


def get_agent_engine():
    settings = get_settings()
    llm = QwenProvider(api_key=settings.qwen_api_key, model=settings.qwen_model)
    return AgentEngine(llm=llm)


@router.post("/upload")
async def upload_file(file: UploadFile = File(...), note_type: NoteType = Form(NoteType.FULL), db: AsyncSession = Depends(get_db)):
    with tempfile.NamedTemporaryFile(delete=False, suffix=".pdf") as tmp:
        content = await file.read()
        tmp.write(content)
        tmp_path = tmp.name
    try:
        engine = get_agent_engine()
        result = await engine.run(content=tmp_path, note_type=note_type.value, source_type="pdf")
        note_service = NoteService(db)
        note = await note_service.create_note(title=file.filename, source_type=SourceType.PDF, content_raw=content.decode("utf-8", errors="ignore"), content_markdown=result["content"], note_type=note_type)
        return {"note_id": note.id, "status": "completed", "content": result["content"]}
    finally:
        os.unlink(tmp_path)


@router.post("/from-url")
async def create_from_url(url: str, note_type: NoteType = NoteType.FULL, db: AsyncSession = Depends(get_db)):
    engine = get_agent_engine()
    result = await engine.run(content=url, note_type=note_type.value, source_type="web")
    note_service = NoteService(db)
    note = await note_service.create_note(title=url, source_type=SourceType.WEB, content_raw=url, content_markdown=result["content"], note_type=note_type, source_url=url)
    return {"note_id": note.id, "status": "completed", "content": result["content"]}


@router.post("/from-text")
async def create_from_text(text: str, title: str = "Untitled", note_type: NoteType = NoteType.FULL, db: AsyncSession = Depends(get_db)):
    engine = get_agent_engine()
    result = await engine.run(content=text, note_type=note_type.value, source_type="text")
    note_service = NoteService(db)
    note = await note_service.create_note(title=title, source_type=SourceType.TEXT, content_raw=text, content_markdown=result["content"], note_type=note_type)
    return {"note_id": note.id, "status": "completed", "content": result["content"]}


@router.get("/")
async def list_notes(skip: int = 0, limit: int = 100, db: AsyncSession = Depends(get_db)):
    note_service = NoteService(db)
    notes = await note_service.get_notes(skip=skip, limit=limit)
    return [{"id": n.id, "title": n.title, "source_type": n.source_type, "note_type": n.note_type, "created_at": n.created_at} for n in notes]


@router.get("/{note_id}")
async def get_note(note_id: str, db: AsyncSession = Depends(get_db)):
    note_service = NoteService(db)
    note = await note_service.get_note(note_id)
    if not note: raise HTTPException(status_code=404, detail="Note not found")
    return {"id": note.id, "title": note.title, "source_type": note.source_type, "source_url": note.source_url, "content_raw": note.content_raw, "content_markdown": note.content_markdown, "note_type": note.note_type, "created_at": note.created_at, "updated_at": note.updated_at}


@router.put("/{note_id}")
async def update_note(note_id: str, content_markdown: str, db: AsyncSession = Depends(get_db)):
    note_service = NoteService(db)
    note = await note_service.update_note(note_id, content_markdown=content_markdown)
    if not note: raise HTTPException(status_code=404, detail="Note not found")
    return {"id": note.id, "status": "updated"}


@router.delete("/{note_id}")
async def delete_note(note_id: str, db: AsyncSession = Depends(get_db)):
    note_service = NoteService(db)
    success = await note_service.delete_note(note_id)
    if not success: raise HTTPException(status_code=404, detail="Note not found")
    return {"status": "deleted"}


@router.get("/{note_id}/export")
async def export_note(note_id: str, format: str = "markdown", db: AsyncSession = Depends(get_db)):
    note_service = NoteService(db)
    note = await note_service.get_note(note_id)
    if not note: raise HTTPException(status_code=404, detail="Note not found")
    if format == "markdown":
        return {"content": note.content_markdown, "filename": f"{note.title}.md"}
    raise HTTPException(status_code=400, detail="Unsupported format")
