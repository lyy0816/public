from app.api.notes import router as notes_router
from app.api.tasks import router as tasks_router

__all__ = ["notes_router", "tasks_router"]
