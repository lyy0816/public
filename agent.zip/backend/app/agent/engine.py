from typing import Dict, Any, Optional
from app.llm.base import LLMProvider
from app.agent.planner import Planner
from app.agent.reflector import Reflector
from app.tools.registry import ToolRegistry


class AgentEngine:
    """Agent引擎 - ReAct循环实现"""

    def __init__(self, llm: LLMProvider, max_steps: int = 10):
        self.llm = llm
        self.planner = Planner(llm)
        self.reflector = Reflector(llm)
        self.tool_registry = ToolRegistry()
        self.max_steps = max_steps

    async def run(self, content: str, note_type: str, source_type: str = "text") -> Dict[str, Any]:
        """
        执行Agent循环

        Args:
            content: 输入内容
            note_type: 笔记类型
            source_type: 来源类型

        Returns:
            包含生成笔记和执行步骤的字典
        """
        steps = []
        context = {"previous_results": ""}

        # 预处理：根据来源类型解析内容
        try:
            if source_type == "pdf":
                processed_content = self.tool_registry.execute("parse_pdf", file_path=content)
            elif source_type == "web":
                processed_content = self.tool_registry.execute("scrape_web", url=content)
            else:
                processed_content = self.tool_registry.execute("process_text", text=content)
        except Exception as e:
            return {
                "content": f"内容预处理失败: {str(e)}",
                "steps": [],
                "metadata": {"source_type": source_type, "note_type": note_type, "error": str(e)}
            }

        # 分块处理长文本
        try:
            if len(processed_content) > 2000:
                chunks = self.tool_registry.execute("split_text_chunks", text=processed_content)
            else:
                chunks = [processed_content]
        except Exception as e:
            chunks = [processed_content]

        all_notes = []

        for i, chunk in enumerate(chunks):
            step_result = await self._process_chunk(chunk, note_type, context, i)
            steps.append(step_result)
            all_notes.append(step_result["result"])
            context["previous_results"] += f"\n\n{step_result['result']}"

        # 合并所有笔记
        try:
            final_note = self.tool_registry.execute("merge_chunks", chunks=all_notes)
        except Exception as e:
            final_note = "\n\n".join(all_notes)

        # 反思检查
        reflection = await self.reflector.reflect(processed_content, final_note)
        steps.append({"step": "reflection", "result": reflection})

        # 如果需要补充，再处理一次
        if reflection.get("should_continue", False) and len(steps) < self.max_steps:
            additional_note = await self._handle_missing(content, final_note, reflection, note_type)
            final_note += f"\n\n## 补充内容\n\n{additional_note}"

        return {
            "content": final_note,
            "steps": steps,
            "metadata": {
                "source_type": source_type,
                "note_type": note_type,
                "chunks_processed": len(chunks)
            }
        }

    async def _process_chunk(self, chunk: str, note_type: str, context: Dict[str, Any], chunk_index: int) -> Dict[str, Any]:
        """处理单个文本块"""
        plan = await self.planner.plan(chunk, note_type, context)

        return {
            "step": chunk_index,
            "action": plan.get("action", "generate"),
            "result": plan.get("result", "")
        }

    async def _handle_missing(self, content: str, current_note: str, reflection: Dict[str, Any], note_type: str) -> str:
        """处理反思中发现的遗漏"""
        missing_info = reflection.get("missing", [])
        suggestions = reflection.get("suggestions", [])

        prompt = f"请补充以下信息到笔记中：\n遗漏：{missing_info}\n建议：{suggestions}"

        messages = [
            {"role": "system", "content": "你是一个笔记补充专家。"},
            {"role": "user", "content": prompt}
        ]

        response = await self.llm.chat(messages)
        return response["content"]
