import json
from typing import Dict, Any
from app.llm.base import LLMProvider


class Reflector:
    """Agent反思模块"""

    def __init__(self, llm: LLMProvider):
        self.llm = llm

    async def reflect(self, content: str, generated_note: str) -> Dict[str, Any]:
        """
        评估生成的笔记质量

        Args:
            content: 原始内容
            generated_note: 生成的笔记

        Returns:
            包含评估结果和建议的字典
        """
        prompt = f"""请评估以下笔记的质量：

原始内容：
{content[:1000]}...

生成的笔记：
{generated_note}

请评估：
1. 是否遗漏了重要信息？
2. 结构是否清晰？
3. 是否需要补充？

请用JSON格式返回：{{"quality": "high/medium/low", "missing": [], "suggestions": [], "should_continue": true/false}}"""

        messages = [
            {"role": "system", "content": "你是一个笔记质量评估专家。"},
            {"role": "user", "content": prompt}
        ]

        response = await self.llm.chat(messages)

        try:
            return json.loads(response["content"])
        except json.JSONDecodeError:
            return {
                "quality": "medium",
                "missing": [],
                "suggestions": [],
                "should_continue": False
            }
