import json
from typing import Dict, Any, List
from app.llm.base import LLMProvider


class Planner:
    """Agent规划模块"""

    def __init__(self, llm: LLMProvider):
        self.llm = llm

    async def plan(self, content: str, note_type: str, context: Dict[str, Any] = None) -> Dict[str, Any]:
        """
        根据内容和笔记类型规划下一步行动

        Args:
            content: 待处理内容
            note_type: 笔记类型（outline/qa/full）
            context: 上下文信息

        Returns:
            包含action和参数的字典
        """
        system_prompt = self._build_system_prompt(note_type)
        user_prompt = self._build_user_prompt(content, context)

        messages = [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt}
        ]

        response = await self.llm.chat(messages)
        return self._parse_response(response["content"])

    def _build_system_prompt(self, note_type: str) -> str:
        json_instruction = '请以JSON格式返回结果，包含"action"和"result"两个字段。例如：{"action": "generate", "result": "笔记内容"}。'
        prompts = {
            "outline": f"你是一个笔记提取专家。请从给定内容中提取关键信息，生成结构化的大纲格式笔记。{json_instruction}",
            "qa": f"你是一个笔记提取专家。请从给定内容中提取关键信息，生成问答对形式的笔记。{json_instruction}",
            "full": f"你是一个笔记提取专家。请从给定内容中提取关键信息，生成完整的笔记，包含摘要、要点和重点标记。{json_instruction}"
        }
        return prompts.get(note_type, prompts["full"])

    def _build_user_prompt(self, content: str, context: Dict[str, Any] = None) -> str:
        prompt = f"请处理以下内容并生成笔记：\n\n{content}"
        if context:
            prompt += f"\n\n之前的处理结果：\n{context.get('previous_results', '')}"
        return prompt

    def _parse_response(self, response: str) -> Dict[str, Any]:
        try:
            return json.loads(response)
        except json.JSONDecodeError:
            return {"action": "finish", "result": response}
