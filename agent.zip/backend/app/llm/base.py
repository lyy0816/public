from abc import ABC, abstractmethod
from typing import List, Dict, Any, AsyncIterator


class LLMProvider(ABC):
    """LLM提供者的抽象基类"""

    @abstractmethod
    async def chat(
        self,
        messages: List[Dict[str, str]],
        tools: List[Dict[str, Any]] = None
    ) -> Dict[str, Any]:
        """发送聊天请求，返回响应"""
        pass

    @abstractmethod
    async def stream_chat(
        self,
        messages: List[Dict[str, str]],
        tools: List[Dict[str, Any]] = None
    ) -> AsyncIterator[str]:
        """流式聊天请求"""
        pass
