import asyncio
from typing import List, Dict, Any, AsyncIterator
from dashscope import Generation
from app.llm.base import LLMProvider


class QwenProvider(LLMProvider):
    """通义千问LLM提供者"""

    def __init__(self, api_key: str, model: str = "qwen-turbo"):
        self.api_key = api_key
        self.model = model

    def _call_api(self, messages: List[Dict[str, str]], **kwargs) -> Any:
        """Synchronous wrapper for Generation.call with per-call api_key."""
        return Generation.call(
            model=self.model,
            messages=messages,
            api_key=self.api_key,
            **kwargs,
        )

    async def chat(
        self,
        messages: List[Dict[str, str]],
        tools: List[Dict[str, Any]] = None
    ) -> Dict[str, Any]:
        kwargs: Dict[str, Any] = {"result_format": "message"}
        if tools is not None:
            kwargs["tools"] = tools

        try:
            response = await asyncio.to_thread(self._call_api, messages, **kwargs)
        except Exception as e:
            raise RuntimeError(f"Qwen API call failed: {e}") from e

        if not response or not response.output or not response.output.choices:
            raise RuntimeError("Qwen API returned an empty response")

        return {
            "content": response.output.choices[0].message.content,
            "usage": response.usage,
        }

    async def stream_chat(
        self,
        messages: List[Dict[str, str]],
        tools: List[Dict[str, Any]] = None
    ) -> AsyncIterator[str]:
        kwargs: Dict[str, Any] = {"result_format": "message", "stream": True}
        if tools is not None:
            kwargs["tools"] = tools

        try:
            responses = await asyncio.to_thread(self._call_api, messages, **kwargs)
        except Exception as e:
            raise RuntimeError(f"Qwen streaming API call failed: {e}") from e

        for response in responses:
            if response.output and response.output.choices:
                yield response.output.choices[0].message.content
