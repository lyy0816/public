import pdfplumber
from app.tools.registry import tool


@tool(name="parse_pdf", description="解析PDF文件，提取文本内容")
def parse_pdf(file_path: str) -> str:
    """
    解析PDF文件并提取文本内容

    Args:
        file_path: PDF文件路径

    Returns:
        提取的文本内容
    """
    text_content = []

    with pdfplumber.open(file_path) as pdf:
        for page in pdf.pages:
            text = page.extract_text()
            if text:
                text_content.append(text)

    return "\n\n".join(text_content)


@tool(name="parse_pdf_pages", description="解析PDF文件的指定页码范围")
def parse_pdf_pages(file_path: str, start_page: int = 0, end_page: int = None) -> str:
    """
    解析PDF文件的指定页码范围

    Args:
        file_path: PDF文件路径
        start_page: 起始页码（从0开始）
        end_page: 结束页码（不包含），None表示到最后

    Returns:
        提取的文本内容
    """
    text_content = []

    with pdfplumber.open(file_path) as pdf:
        if end_page is None:
            end_page = len(pdf.pages)

        for i in range(start_page, min(end_page, len(pdf.pages))):
            text = pdf.pages[i].extract_text()
            if text:
                text_content.append(f"--- 第{i+1}页 ---\n{text}")

    return "\n\n".join(text_content)
