from typing import Callable, Dict, Any, List


class ToolRegistry:
    """工具注册表"""
    _instance = None

    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
            cls._instance._tools: Dict[str, Callable] = {}
        return cls._instance

    @classmethod
    def clear(cls):
        """清空注册表（用于测试）"""
        cls()._tools.clear()

    @classmethod
    def register(cls, name: str, description: str):
        """工具装饰器"""
        def decorator(func):
            func._tool_name = name
            func._tool_description = description
            cls()._tools[name] = func
            return func
        return decorator

    @classmethod
    def get_tool(cls, name: str) -> Callable:
        """获取工具"""
        tools = cls()._tools
        if name not in tools:
            raise KeyError(f"Tool '{name}' not found")
        return tools[name]

    @classmethod
    def execute(cls, name: str, **kwargs) -> Any:
        """执行工具"""
        tool = cls.get_tool(name)
        return tool(**kwargs)

    @classmethod
    def list_tools(cls) -> List[Dict[str, str]]:
        """列出所有工具"""
        return [
            {"name": name, "description": tool._tool_description}
            for name, tool in cls()._tools.items()
        ]


def tool(name: str, description: str):
    """工具装饰器的快捷方式"""
    return ToolRegistry.register(name, description)
