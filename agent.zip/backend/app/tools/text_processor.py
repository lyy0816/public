from typing import List
from app.tools.registry import tool


@tool(name="process_text", description="处理纯文本输入，进行清洗和分段")
def process_text(text: str) -> str:
    """
    处理纯文本，清洗并保留结构

    Args:
        text: 输入文本

    Returns:
        处理后的文本
    """
    # 移除多余空白
    lines = text.split("\n")
    cleaned_lines = []

    for line in lines:
        stripped = line.strip()
        if stripped:
            cleaned_lines.append(stripped)

    return "\n".join(cleaned_lines)


@tool(name="split_text_chunks", description="将长文本按段落分块")
def split_text_chunks(text: str, max_chunk_size: int = 2000) -> List[str]:
    """
    将长文本分块，每块不超过max_chunk_size字符

    Args:
        text: 输入文本
        max_chunk_size: 每块最大字符数

    Returns:
        文本块列表
    """
    paragraphs = text.split("\n\n")
    chunks = []
    current_chunk = []
    current_size = 0

    for para in paragraphs:
        para_size = len(para)

        if current_size + para_size > max_chunk_size and current_chunk:
            chunks.append("\n\n".join(current_chunk))
            current_chunk = [para]
            current_size = para_size
        else:
            current_chunk.append(para)
            current_size += para_size

    if current_chunk:
        chunks.append("\n\n".join(current_chunk))

    return chunks


@tool(name="merge_chunks", description="合并多个文本块")
def merge_chunks(chunks: List[str], separator: str = "\n\n---\n\n") -> str:
    """
    合并多个文本块

    Args:
        chunks: 文本块列表
        separator: 分隔符

    Returns:
        合并后的文本
    """
    return separator.join(chunks)
