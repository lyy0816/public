import requests
from bs4 import BeautifulSoup
from app.tools.registry import tool


@tool(name="scrape_web", description="抓取网页内容，过滤广告和导航")
def scrape_web(url: str) -> str:
    """
    抓取网页内容并提取主要文本

    Args:
        url: 网页URL

    Returns:
        提取的文本内容
    """
    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"
    }

    response = requests.get(url, headers=headers, timeout=30)
    response.raise_for_status()
    response.encoding = response.apparent_encoding

    soup = BeautifulSoup(response.text, "html.parser")

    # 移除不需要的标签
    for tag in soup(["script", "style", "nav", "footer", "header", "aside"]):
        tag.decompose()

    # 提取主要内容
    content = []

    # 优先提取article或main标签
    main_content = soup.find("article") or soup.find("main") or soup.find("body")

    if main_content:
        for element in main_content.find_all(["h1", "h2", "h3", "h4", "p", "li"]):
            text = element.get_text(strip=True)
            if text:
                if element.name.startswith("h"):
                    level = int(element.name[1])
                    content.append(f"\n{'#' * level} {text}\n")
                else:
                    content.append(text)

    return "\n\n".join(content)


@tool(name="scrape_web_raw", description="抓取网页原始HTML内容")
def scrape_web_raw(url: str) -> str:
    """
    抓取网页原始HTML

    Args:
        url: 网页URL

    Returns:
        原始HTML内容
    """
    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"
    }

    response = requests.get(url, headers=headers, timeout=30)
    response.raise_for_status()
    return response.text
