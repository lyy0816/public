# 前端 - Agent Note Extraction

## 安装

```bash
npm install
```

## 运行

```bash
npm start
```

访问 http://localhost:3000

## 构建

```bash
npm run build
```

## 主要页面

- `/` - 首页，上传文件或输入内容
- `/notes` - 笔记列表
- `/notes/:id` - 笔记详情
