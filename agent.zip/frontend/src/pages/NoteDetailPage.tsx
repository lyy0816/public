import React, { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { Card, Button, message, Spin } from 'antd';
import { EditOutlined, DownloadOutlined, ArrowLeftOutlined } from '@ant-design/icons';
import { noteApi, Note } from '../api/client';
import NoteViewer from '../components/NoteViewer';
import NoteEditor from '../components/NoteEditor';

const NoteDetailPage: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const [note, setNote] = useState<Note | null>(null);
  const [loading, setLoading] = useState<boolean>(false);
  const [editing, setEditing] = useState<boolean>(false);

  const fetchNote = async () => {
    if (!id) return;
    setLoading(true);
    try {
      const response = await noteApi.get(id);
      setNote(response.data);
    } catch (error) {
      message.error('获取笔记失败');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { fetchNote(); }, [id]);

  const handleExport = async () => {
    if (!id) return;
    try {
      const response = await noteApi.export(id);
      const blob = new Blob([response.data.content], { type: 'text/markdown' });
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = response.data.filename || 'note.md';
      a.click();
      window.URL.revokeObjectURL(url);
    } catch (error) {
      message.error('导出失败');
    }
  };

  const handleSave = (content: string) => {
    if (note) { setNote({ ...note, content_markdown: content }); }
    setEditing(false);
  };

  if (loading) { return <Spin size="large" style={{ display: 'block', margin: '100px auto' }} />; }
  if (!note) { return <div>笔记不存在</div>; }

  return (
    <div style={{ maxWidth: 1000, margin: '0 auto' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 16 }}>
        <Button icon={<ArrowLeftOutlined />} onClick={() => navigate('/notes')}>返回列表</Button>
        <div>
          <Button icon={<EditOutlined />} onClick={() => setEditing(!editing)} style={{ marginRight: 8 }}>{editing ? '取消编辑' : '编辑'}</Button>
          <Button icon={<DownloadOutlined />} onClick={handleExport}>导出</Button>
        </div>
      </div>
      <Card title={note.title}>
        {editing ? (
          <NoteEditor noteId={note.id} initialContent={note.content_markdown} onSave={handleSave} />
        ) : (
          <NoteViewer content={note.content_markdown} />
        )}
      </Card>
    </div>
  );
};

export default NoteDetailPage;
