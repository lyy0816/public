import React from 'react';
import { useNavigate } from 'react-router-dom';
import { Typography, Card } from 'antd';
import FileUpload from '../components/FileUpload';

const { Title, Paragraph } = Typography;

const HomePage: React.FC = () => {
  const navigate = useNavigate();

  const handleSuccess = (noteId: string) => {
    navigate(`/notes/${noteId}`);
  };

  return (
    <div style={{ maxWidth: 800, margin: '0 auto' }}>
      <Typography>
        <Title level={2}>Agent驱动的自动笔记提取</Title>
        <Paragraph>上传PDF文件、输入网页URL或粘贴文本，AI Agent将自动提取关键信息并生成结构化笔记。</Paragraph>
      </Typography>
      <Card title="生成笔记" style={{ marginTop: 24 }}>
        <FileUpload onSuccess={handleSuccess} />
      </Card>
    </div>
  );
};

export default HomePage;
