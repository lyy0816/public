import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Table, Tag, Button, message, Popconfirm } from 'antd';
import { EyeOutlined, DeleteOutlined } from '@ant-design/icons';
import { noteApi, Note } from '../api/client';

const NoteListPage: React.FC = () => {
  const navigate = useNavigate();
  const [notes, setNotes] = useState<Note[]>([]);
  const [loading, setLoading] = useState<boolean>(false);

  const fetchNotes = async () => {
    setLoading(true);
    try {
      const response = await noteApi.list();
      setNotes(response.data);
    } catch (error) {
      message.error('获取笔记列表失败');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { fetchNotes(); }, []);

  const handleDelete = async (id: string) => {
    try {
      await noteApi.delete(id);
      message.success('删除成功');
      fetchNotes();
    } catch (error) {
      message.error('删除失败');
    }
  };

  const columns = [
    {
      title: '标题', dataIndex: 'title', key: 'title',
      render: (text: string, record: Note) => <a onClick={() => navigate(`/notes/${record.id}`)}>{text}</a>,
    },
    {
      title: '来源', dataIndex: 'source_type', key: 'source_type',
      render: (type: string) => {
        const colorMap: Record<string, string> = { pdf: 'blue', web: 'green', text: 'orange' };
        return <Tag color={colorMap[type]}>{type.toUpperCase()}</Tag>;
      },
    },
    {
      title: '笔记类型', dataIndex: 'note_type', key: 'note_type',
      render: (type: string) => {
        const labelMap: Record<string, string> = { outline: '大纲', qa: '问答', full: '完整' };
        return <Tag>{labelMap[type]}</Tag>;
      },
    },
    {
      title: '创建时间', dataIndex: 'created_at', key: 'created_at',
      render: (date: string) => new Date(date).toLocaleString(),
    },
    {
      title: '操作', key: 'action',
      render: (_: any, record: Note) => (
        <>
          <Button type="link" icon={<EyeOutlined />} onClick={() => navigate(`/notes/${record.id}`)}>查看</Button>
          <Popconfirm title="确定删除此笔记？" onConfirm={() => handleDelete(record.id)} okText="确定" cancelText="取消">
            <Button type="link" danger icon={<DeleteOutlined />}>删除</Button>
          </Popconfirm>
        </>
      ),
    },
  ];

  return (
    <div>
      <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 16 }}>
        <h2>笔记列表</h2>
        <Button type="primary" onClick={() => navigate('/')}>新建笔记</Button>
      </div>
      <Table columns={columns} dataSource={notes} rowKey="id" loading={loading} />
    </div>
  );
};

export default NoteListPage;
