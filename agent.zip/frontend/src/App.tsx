import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { Layout, Menu } from 'antd';
import { HomeOutlined, UnorderedListOutlined } from '@ant-design/icons';
import HomePage from './pages/HomePage';
import NoteListPage from './pages/NoteListPage';
import NoteDetailPage from './pages/NoteDetailPage';

const { Header, Content, Footer } = Layout;

const App: React.FC = () => {
  return (
    <Router>
      <Layout style={{ minHeight: '100vh' }}>
        <Header style={{ display: 'flex', alignItems: 'center' }}>
          <div style={{ color: 'white', fontSize: '18px', fontWeight: 'bold', marginRight: '40px' }}>Agent Note Extraction</div>
          <Menu theme="dark" mode="horizontal" defaultSelectedKeys={['home']}
            items={[
              { key: 'home', icon: <HomeOutlined />, label: '首页' },
              { key: 'notes', icon: <UnorderedListOutlined />, label: '笔记列表' },
            ]}
            onClick={({ key }) => { window.location.href = key === 'home' ? '/' : '/notes'; }}
          />
        </Header>
        <Content style={{ padding: '24px 50px' }}>
          <Routes>
            <Route path="/" element={<HomePage />} />
            <Route path="/notes" element={<NoteListPage />} />
            <Route path="/notes/:id" element={<NoteDetailPage />} />
          </Routes>
        </Content>
        <Footer style={{ textAlign: 'center' }}>Agent Note Extraction System</Footer>
      </Layout>
    </Router>
  );
};

export default App;
