import axios from 'axios';

const apiClient = axios.create({
  baseURL: 'http://localhost:8000',
  headers: { 'Content-Type': 'application/json' },
});

export interface Note {
  id: string;
  title: string;
  source_type: 'pdf' | 'web' | 'text';
  source_url?: string;
  content_raw: string;
  content_markdown: string;
  note_type: 'outline' | 'qa' | 'full';
  created_at: string;
  updated_at: string;
}

export interface Task {
  id: string;
  note_id?: string;
  status: 'pending' | 'running' | 'completed' | 'failed';
  steps: any[];
  result?: string;
  created_at: string;
}

export const noteApi = {
  upload: (file: File, noteType: string) => {
    const formData = new FormData();
    formData.append('file', file);
    formData.append('note_type', noteType);
    return apiClient.post('/api/notes/upload', formData);
  },
  fromUrl: (url: string, noteType: string) => apiClient.post('/api/notes/from-url', null, { params: { url, note_type: noteType } }),
  fromText: (text: string, title: string, noteType: string) => apiClient.post('/api/notes/from-text', null, { params: { text, title, note_type: noteType } }),
  list: (skip = 0, limit = 100) => apiClient.get<Note[]>('/api/notes/', { params: { skip, limit } }),
  get: (id: string) => apiClient.get<Note>(`/api/notes/${id}`),
  update: (id: string, content: string) => apiClient.put(`/api/notes/${id}`, null, { params: { content_markdown: content } }),
  delete: (id: string) => apiClient.delete(`/api/notes/${id}`),
  export: (id: string, format = 'markdown') => apiClient.get(`/api/notes/${id}/export`, { params: { format } }),
};

export const taskApi = {
  get: (id: string) => apiClient.get<Task>(`/api/tasks/${id}`),
};

export default apiClient;
