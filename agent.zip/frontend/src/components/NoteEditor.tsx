import React, { useState } from 'react';
import { Button, message } from 'antd';
import { SaveOutlined } from '@ant-design/icons';
import { noteApi } from '../api/client';

interface NoteEditorProps {
  noteId: string;
  initialContent: string;
  onSave: (content: string) => void;
}

const NoteEditor: React.FC<NoteEditorProps> = ({ noteId, initialContent, onSave }) => {
  const [content, setContent] = useState<string>(initialContent);
  const [saving, setSaving] = useState<boolean>(false);

  const handleSave = async () => {
    setSaving(true);
    try {
      await noteApi.update(noteId, content);
      message.success('保存成功');
      onSave(content);
    } catch (error) {
      message.error('保存失败');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div>
      <textarea value={content} onChange={(e) => setContent(e.target.value)}
        style={{ width: '100%', minHeight: '400px', padding: '16px', fontFamily: 'monospace', fontSize: '14px', border: '1px solid #d9d9d9', borderRadius: '4px' }} />
      <div style={{ marginTop: '16px' }}>
        <Button type="primary" icon={<SaveOutlined />} onClick={handleSave} loading={saving}>保存</Button>
      </div>
    </div>
  );
};

export default NoteEditor;
