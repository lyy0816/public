import React from 'react';
import ReactMarkdown from 'react-markdown';

interface NoteViewerProps {
  content: string;
}

const NoteViewer: React.FC<NoteViewerProps> = ({ content }) => {
  return (
    <div style={{ padding: '24px', background: '#fff', borderRadius: '8px' }}>
      <ReactMarkdown>{content}</ReactMarkdown>
    </div>
  );
};

export default NoteViewer;
