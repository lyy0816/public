import React, { useState } from 'react';
import { Upload, Button, Select, message } from 'antd';
import { UploadOutlined, LinkOutlined, FileTextOutlined } from '@ant-design/icons';
import { noteApi } from '../api/client';

const { Option } = Select;

interface FileUploadProps {
  onSuccess: (noteId: string) => void;
}

const FileUpload: React.FC<FileUploadProps> = ({ onSuccess }) => {
  const [noteType, setNoteType] = useState<string>('full');
  const [url, setUrl] = useState<string>('');
  const [text, setText] = useState<string>('');
  const [loading, setLoading] = useState<boolean>(false);
  const [inputMode, setInputMode] = useState<'file' | 'url' | 'text'>('file');

  const handleFileUpload = async (file: File) => {
    setLoading(true);
    try {
      const response = await noteApi.upload(file, noteType);
      message.success('笔记生成成功！');
      onSuccess(response.data.note_id);
    } catch (error) {
      message.error('上传失败，请重试');
    } finally {
      setLoading(false);
    }
  };

  const handleUrlSubmit = async () => {
    if (!url.trim()) { message.warning('请输入URL'); return; }
    setLoading(true);
    try {
      const response = await noteApi.fromUrl(url, noteType);
      message.success('笔记生成成功！');
      onSuccess(response.data.note_id);
    } catch (error) {
      message.error('处理失败，请重试');
    } finally {
      setLoading(false);
    }
  };

  const handleTextSubmit = async () => {
    if (!text.trim()) { message.warning('请输入文本内容'); return; }
    setLoading(true);
    try {
      const response = await noteApi.fromText(text, '未命名笔记', noteType);
      message.success('笔记生成成功！');
      onSuccess(response.data.note_id);
    } catch (error) {
      message.error('处理失败，请重试');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div style={{ padding: '24px', background: '#fff', borderRadius: '8px' }}>
      <div style={{ marginBottom: '16px' }}>
        <Select value={noteType} onChange={setNoteType} style={{ width: 200, marginRight: 16 }}>
          <Option value="outline">大纲笔记</Option>
          <Option value="qa">问答卡片</Option>
          <Option value="full">完整笔记</Option>
        </Select>
        <Select value={inputMode} onChange={setInputMode} style={{ width: 200 }}>
          <Option value="file"><UploadOutlined /> 上传文件</Option>
          <Option value="url"><LinkOutlined /> 输入URL</Option>
          <Option value="text"><FileTextOutlined /> 输入文本</Option>
        </Select>
      </div>
      {inputMode === 'file' && (
        <Upload accept=".pdf,.txt,.md" showUploadList={false} beforeUpload={(file) => { handleFileUpload(file); return false; }}>
          <Button icon={<UploadOutlined />} loading={loading}>选择文件上传</Button>
        </Upload>
      )}
      {inputMode === 'url' && (
        <div>
          <input type="text" value={url} onChange={(e) => setUrl(e.target.value)} placeholder="输入网页URL"
            style={{ width: '100%', padding: '8px', marginBottom: '8px', border: '1px solid #d9d9d9', borderRadius: '4px' }} />
          <Button type="primary" onClick={handleUrlSubmit} loading={loading}>生成笔记</Button>
        </div>
      )}
      {inputMode === 'text' && (
        <div>
          <textarea value={text} onChange={(e) => setText(e.target.value)} placeholder="粘贴文本内容" rows={6}
            style={{ width: '100%', padding: '8px', marginBottom: '8px', border: '1px solid #d9d9d9', borderRadius: '4px' }} />
          <Button type="primary" onClick={handleTextSubmit} loading={loading}>生成笔记</Button>
        </div>
      )}
    </div>
  );
};

export default FileUpload;
