# Agent驱动的自动笔记提取系统

基于智能Agent技术的自动笔记提取系统，能够从多种来源（PDF、网页、文本）自动生成结构化的笔记。

## 功能特点

- **多源输入**：支持PDF文件、网页URL、纯文本输入
- **智能提取**：Agent自动规划提取步骤，分段处理长文档
- **多种输出**：大纲笔记、问答卡片、完整笔记
- **编辑导出**：支持在线编辑和Markdown导出

## 技术栈

- **后端**：Python, FastAPI, SQLAlchemy, SQLite
- **前端**：React, TypeScript, Ant Design
- **AI**：通义千问API (可切换其他LLM)

## 快速开始

### 后端

```bash
cd backend
pip install -r requirements.txt
cp .env.example .env  # 配置API Key
uvicorn app.main:app --reload
```

### 前端

```bash
cd frontend
npm install
npm start
```

访问 http://localhost:3000

## 项目结构

```
agent/
├── backend/          # Python后端
│   ├── app/
│   │   ├── agent/    # Agent核心引擎
│   │   ├── api/      # API路由
│   │   ├── llm/      # LLM抽象层
│   │   ├── models/   # 数据模型
│   │   └── tools/    # 工具注册表
│   └── tests/
├── frontend/         # React前端
│   └── src/
│       ├── pages/
│       └── components/
└── docs/             # 文档
```

## API文档

启动后端后访问 http://localhost:8000/docs
